/**
 * Tate Dyer
 * Lab 4
 */

package game;

import heroes.Berserker;
import heroes.Hero;
import heroes.Heroes;

import static game.Team.DRAGON;
import static game.Team.LION;

public class HeroStorm {

    private HeroParty dragon;
    private HeroParty lion;
    private int roundCounter;

    /**
     * constructs the 2 parties to be used and initializes the round
     * @param dragonSeed
     * @param lionSeed
     */
    public HeroStorm( int dragonSeed, int lionSeed)
    {
        dragon=new HeroParty(DRAGON, dragonSeed);
        lion=new HeroParty(LION, lionSeed);
        roundCounter=1;
    }

    /**
     * plays the game and continues till a team is all dead leaving the other victorious
     */
    public void play()
    {
        while(dragon.numHeroes()>0 && lion.numHeroes()>0)
        {
            System.out.println("Battle #"+ roundCounter);
            System.out.println("==========");
            System.out.println(dragon.toString());
            System.out.println(lion.toString());
            System.out.println("");
            if(roundCounter%2==1)
            {
               Hero heroD=dragon.removeHero();
               Hero heroL=lion.removeHero();
               System.out.println("*** "+heroD.getName()+" vs "+ heroL.getName());
               heroD.attack(heroL);
               if(!heroL.hasFallen())
               {
                   heroL.attack(heroD);
                   if(heroD.hasFallen())
                   {
                       System.out.println(heroD.getName()+" has been vanquished");
                   }
                   else
                   {
                       dragon.addHero(heroD);
                   }
                   lion.addHero(heroL);
               }
               else
               {
                   System.out.println(heroL.getName()+" has been vanquished");
                   dragon.addHero(heroD);
               }

            }
            else
            {
                Hero heroL=lion.removeHero();
                Hero heroD=dragon.removeHero();
                System.out.println("*** "+heroL.getName()+" vs "+ heroD.getName());
                heroL.attack(heroD);
                if(!heroD.hasFallen())
                {
                    heroD.attack(heroL);
                    if(heroL.hasFallen())
                    {
                        System.out.println(heroL.getName()+" has been vanquished");
                    }
                    else
                    {
                        lion.addHero(heroL);
                    }
                    dragon.addHero(heroD);
                }
                else
                {
                    System.out.println(heroD.getName()+" has been vanquished");
                    lion.addHero(heroL);
                }
            }
            System.out.println("");
            roundCounter++;
        }
        if(dragon.numHeroes()==0)
        {
            System.out.println("Team Lion wins!");
        }
        else
        {
            System.out.println("Team Dragon wins!");
        }

    }

    /**
     * main method which takes in 2 command arguments to play the game
     * @param args
     */
    public static void main(String[] args)
    {
        if(args.length==2)
        {
            HeroStorm heroes = new HeroStorm(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
            heroes.play();
        }


    }
}
