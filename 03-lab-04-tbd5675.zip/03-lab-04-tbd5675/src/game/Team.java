/**
 * Tate Dyer
 * Lab 4
 */

package game;

/**
 * allows heroes to be assigned to a team
 */
public enum Team
{
    DRAGON,
    LION;
}
