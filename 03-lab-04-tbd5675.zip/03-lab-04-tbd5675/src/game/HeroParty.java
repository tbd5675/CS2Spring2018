/**
 * Tate Dyer
 * Lab 4
 */

package game;

import heroes.Berserker;
import heroes.Hero;
import heroes.Heroes;
import heroes.Party;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import static game.Team.LION;

public class HeroParty implements Party{

    private List<Hero> heroes=new LinkedList<>();
    private Team team;

    /**
     * constructs the party for a team and randomizes them
     * @param team that they are a part of
     * @param seed used to randomize
     */
    public HeroParty(Team team, int seed)
    {
        this.team=team;
        heroes.add(Hero.create(Heroes.Role.BERSERKER, team, this));
        heroes.add(Hero.create(Heroes.Role.HEALER, team, this));
        heroes.add(Hero.create(Heroes.Role.TANK, team, this));
        Collections.shuffle(this.heroes, new Random(seed));
    }

    /**
     * adds the hero to the back of the list
     * @param hero the new hero
     */
    public void addHero(Hero hero)
    {
        heroes.add(hero);
    }

    /**
     * removes the front hero
     * @return the hero removed
     */
    public Hero removeHero()
    {
        return heroes.remove(0);
    }

    /**
     * gets the the number of heroes in the list
     * @return number of heroes in the list
     */
    public int numHeroes()
    {
        return heroes.size();
    }

    /**
     * gets the team
     * @return the team the heroes are on
     */
    public Team getTeam()
    {
        return team;
    }

    /**
     * gets the list of heroes
     * @return list of heroes
     */
    public java.util.List<Hero> getHeroes()
    {
        return heroes;
    }

    /**
     * prints out party of the given team
     * @return
     */
    public String toString()
    {
        StringBuilder party=new StringBuilder();
        if(getTeam()==LION)
        {
            party.append("Lions: ");
            party.append(System.lineSeparator());
        }
        else
        {
            party.append("Dragons: ");
            party.append(System.lineSeparator());
        }
        for(Hero hero : heroes)
        {
            party.append(hero);
        }
        return party.toString();
    }
}
