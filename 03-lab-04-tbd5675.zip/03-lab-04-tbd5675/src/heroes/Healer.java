/**
 * Tate Dyer
 * Lab 4
 */

package heroes;

import game.Team;

public class Healer extends Hero{
    protected  static int DAMAGE_AMOUNT=10;
    protected  static int HEAL_AMOUNT=10;
    protected  static int HEALER_HIT_POINTS=35;
    protected Party party;

    /**
     * constructs the healer based on the team and the party group
     * @param team
     * @param party
     */
    protected  Healer(Team team, Party party)
    {
        super(Heroes.getName(team, Heroes.Role.HEALER), HEALER_HIT_POINTS);
        this.party=party;
    }

    /**
     * gets the Healer role
     * @return
     */
    public Heroes.Role getRole()
    {
        return Heroes.Role.HEALER;
    }

    /**
     * attacks given enemy with amount of damage and also heals team and itself beforehand
     * @param enemy
     */
    public void attack(Hero enemy)
    {
        heal(HEAL_AMOUNT);
        for(Hero hero : party.getHeroes())
        {
            hero.heal(HEAL_AMOUNT);
        }
        enemy.takeDamage(DAMAGE_AMOUNT);
    }

}
