/**
 * Tate Dyer
 * Lab 4
 */

package heroes;

import game.Team;

public abstract class Hero extends Object{

    private String name;
    private int hitPoints;
    private int maxHP;

    /**
     * constructs a hero with its name and HP
     * @param name
     * @param hitPoints
     */
    protected Hero(String name, int hitPoints)
    {
        this.name=name;
        this.hitPoints=hitPoints;
        maxHP=hitPoints;
    }

    /**
     * used to create a hero given role, team and party
     * @param role healer, berserker or tank
     * @param team dragon or lion
     * @param party group within the team
     * @return
     */
    public static Hero create(Heroes.Role role, Team team, Party party)
    {
        if(role== Heroes.Role.HEALER)
        {
            return new Healer(team,party);
        }
        else if(role== Heroes.Role.TANK)
        {
            return new Tank(team);
        }
        else
        {
            return new Berserker(team);
        }
    }

    /**
     * all heroes have but accessed different in each
     * @return
     */
    public abstract Heroes.Role getRole();

    /**
     * all heroes have but done different in each
     * @return
     */
    public abstract void attack(Hero enemy);

    /**
     * gets the name of the hero
     * @return name
     */
    public String getName()
    {
        return name;
    }

    /**
     * increases HP based on amount to heal
     * @param amount
     */
    public void heal(int amount)
    {
        if(hitPoints+amount>maxHP)
        {
            System.out.println(getName()+" heals "+amount+" points");
            hitPoints=maxHP;
        }
        else
        {
            System.out.println(getName()+" heals "+amount+" points");
            hitPoints=hitPoints+amount;
        }
    }

    /**
     * takes away amount of HP due to damage but will not go below 0
     * @param amount
     */
    public void takeDamage(int amount)
    {
        if(hitPoints-amount<0)
        {
            hitPoints=0;
        }
        else
            {
            hitPoints=hitPoints-amount;
        }

        System.out.println(getName()+" takes "+amount+" damage");
    }

    /**
     * checks if the hero is dead or not
     * @return true or false
     */
    public boolean hasFallen()
    {
        if(hitPoints<=0)
        {
            return true;
        }
        return false;
    }

    /**
     * prints out the hero name, role and HP percent
     * @return string
     */
    public String toString()
    {
        return (getName()+", "+getRole()+", "+hitPoints+"/"+maxHP+"\n");
    }
}
