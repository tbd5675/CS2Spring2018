/**
 * Tate Dyer
 * Lab 4
 */

package heroes;

import game.Team;

public class Berserker extends Hero{

    protected  static int DAMAGE_AMOUNT=20;
    protected  static int BERSERKER_HIT_POINTS=30;

    /**
     * constructs the Berserker given the team
     * @param team
     */
    protected Berserker(Team team)
    {
        super(Heroes.getName(team, Heroes.Role.BERSERKER), BERSERKER_HIT_POINTS);
    }

    /**
     * gets the Berserker role
     * @return
     */
    public Heroes.Role getRole()
    {
        return Heroes.Role.BERSERKER;
    }

    /**
     * attacks given enemy with amount of damage
     * @param enemy
     */
    public void attack(Hero enemy)
    {
        enemy.takeDamage(DAMAGE_AMOUNT);
    }
}
