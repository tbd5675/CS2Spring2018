/**
 * Tate Dyer
 * Lab 4
 */

package heroes;

import game.Team;

public class Tank extends Hero{

    protected static int DAMAGE_AMOUNT=15;
    protected static final double SHIELD_DMG_MULTIPLIER=.9;
    protected static int TANK_HIT_POINTS=40;

    /**
     * constructs Tank given the team
     * @param team
     */
    protected Tank(Team team)
    {
        super(Heroes.getName(team, Heroes.Role.TANK), TANK_HIT_POINTS);
    }

    /**
     * gets the tank role
     * @return
     */
    public Heroes.Role getRole()
    {
        return Heroes.Role.TANK;
    }

    /**
     * given amount of incoming damage calls super class to change HP
     * @param amount
     */
    public void takeDamage(int amount)
    {
        super.takeDamage((int)(SHIELD_DMG_MULTIPLIER*amount));
    }

    /**
     * attacks given enemy with amount of damage
     * @param enemy
     */
    public void attack(Hero enemy)
    {
        enemy.takeDamage(DAMAGE_AMOUNT);
    }
}
