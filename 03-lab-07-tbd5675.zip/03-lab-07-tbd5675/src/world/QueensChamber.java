package world;

import bee.Drone;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * The queen's chamber is where the mating ritual between the queen and her
 * drones is conducted.  The drones will enter the chamber in order.
 * If the queen is ready and a drone is in here, the first drone will
 * be summoned and mate with the queen.  Otherwise the drone has to wait.
 * After a drone mates they perish, which is why there is no routine
 * for exiting (like with the worker bees and the flower field).
 *
 * @author Sean Strout @ RIT CS
 * @author YOUR NAME HERE
 */
public class QueensChamber {

    private ConcurrentLinkedQueue<Drone> drones;
    private boolean readyToMate;

    /**
     * constructor for chamber that makes the collection of drones in it
     */
    public QueensChamber()
    {
        drones=new ConcurrentLinkedQueue<>();
        readyToMate=false;
    }

    /**
     * the bee enters the chamber and is stored in a collection.  If the queen is ready and this drone
     * is at the front of the collection, they are allowed to mate. Otherwise they must wait. Displays message
     * when drone leave
     * @param drone the new drone
     */
    public synchronized void enterChamber(Drone drone)
    {
        System.out.println("*QC* " + drone + " enters chamber");
        drones.add(drone);
        while(!readyToMate || drone!=drones.peek())
        {
            try {
                wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("*QC* " + drone + " leaves chamber");

    }

    /**
     * When the queen is ready, they will summon the next drone from the collection (if at least one is there).
     * The queen will mate with the first drone and display a message
     */
    public synchronized void summonDrone()
    {
        if(hasDrone())
        {
            readyToMate=true;
            Drone mate= drones.peek();
            System.out.println("*QC* Queen mates with " + mate);
            mate.setMated();
            notifyAll();
        }
    }

    /**
     * Used to dismiss drones that were waiting at end of simulation
     */
    public synchronized void dismissDrone()
    {
        Drone drone=drones.peek();
        drones.remove(drone);
    }

    /**
     * checks if drones waiting. queen uses to check if she can mate
     * @return boolean
     */
    public synchronized boolean hasDrone()
    {
        if(drones.isEmpty())
        {
            return false;
        }
        return true;
    }

    public void setReadyToMate()
    {
        readyToMate=false;
    }
}