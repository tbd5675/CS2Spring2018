/**
 * Tate Dyer
 * Lab 02
 */
package game;

import java.util.Scanner;

public class DotsAndBoxes
{
    public String PROMPT=""; //will scan user input
    //private GameBoard;

    public DotsAndBoxes(int a, int b)
    {

    }

    private boolean makeMove(Scanner input)
    {
        return true;
    }

    public void play()
    {

    }

    public static void main(String[] args)
    {
	// write your code here
    }
}
