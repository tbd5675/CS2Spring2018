/**
 * Tate Dyer
 * Lab 02
 */
package game;

public class GameBoard
{
    private int rows;
    private int columns;
    private int redScore;
    private int blueScore;
    private Player player;
    private Dot[][] dot;
    private Lines lines;
    private Box[][] boxes;
    private int moves;

    /**
     * checks if all lines have been claimed comparing lines to moves
     * @return game over or nah man
     */
    public boolean gameOver()
    {
        return false;
    }

    /**
     * whose turn it is
     * @return the player who can play
     */
    public Player whoseTurn()
    {
        return player;
    }

    /**
     * checks if the line coordinates exist and are unclaimed
     * @param r1
     * @param c1
     * @param r2
     * @param c2
     * @return
     */
    public boolean isLineValid(int r1, int c1, int r2, int c2)
    {
        return false;
    }

    /**
     * makes move given valid claim and if box is claimed goes again
     * @param r1
     * @param c1
     * @param r2
     * @param c2
     */
    public void makeMove(int r1, int c1, int r2, int c2)
    {

    }

    public String toString()
    {
        return "";
    }

}
