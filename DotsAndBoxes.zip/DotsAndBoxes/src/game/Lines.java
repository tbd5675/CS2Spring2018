/**
 * Tate Dyer
 * Lab 02
 */
package game;

import java.util.ArrayList;

public class Lines
{
    private java.util.ArrayList<Line> lines=new ArrayList<>();

    /**
     * constructor for lines
     * @param rows
     * @param columns
     * @param dots
     */
    public Lines(int rows, int columns, Dot[][] dots)
    {
        for(int row=0; row<=rows; row++)
        {
            for(int column=0; column<=columns; column++)
            {
                if(column!=columns)
                {
                    this.lines.add(new Line(dots[row][column], dots[row][column+1]));
                }
                if (row!=rows)
                {
                    this.lines.add(new Line(dots[row][column], dots[row+1][column]));
                }
            }
        }
    }

    /**
     * gets line from 2 dots
     * @param row1
     * @param column1
     * @param row2
     * @param column2
     * @return
     */
    public Line getLine(int row1, int column1, int row2, int column2)
    {
        for(Line line: lines)
        {
            if (line.getFirst().getRow()==row1 && line.getFirst().getColumn() == column1)
            {
                if (line.getSecond().getRow()==row2 && line.getSecond().getColumn() == column2)
                {
                    return line;
                }
            }
        }
        return null;
    }

    public int size()
    {
      return lines.size();
    }
}
