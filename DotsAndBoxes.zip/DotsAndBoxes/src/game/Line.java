/**
 * Tate Dyer
 * Lab 02
 */
package game;

import java.util.ArrayList;

public class Line
{
    public static final String EMPTY=" ";
    public static final String HORI_LINE="-";
    public static final String VERT_LINE="|";
    private Dot first;
    private Dot second;
    private Player owner;
    private java.util.ArrayList<Box> boxes=new ArrayList<>();

    /**
     * constructor of a line
     * @param first dot
     * @param second dot
     */
    public Line(Dot first, Dot second)
    {
        assert first.getRow()<=second.getRow() && first.getColumn()<=second.getColumn();
        this.first=first;
        this.second=second;
        owner=Player.NONE;
    }

    /**
     * get first dot
     * @return first dot
     */
    public Dot getFirst()
    {
        return first;
    }

    /**
     * gets the second dot
     * @return second dot
     */
    public Dot getSecond()
    {
        return second;
    }

    /**
     * gets the owner of the line
     * @return owner
     */
    public Player getOwner()
    {
        return owner;
    }

    /**
     * gets the boxes that are associated with the line
     * @return an array of boxes
     */
    public java.util.ArrayList<Box> getBoxes()
    {
       return boxes;
    }

    /**
     * checks to see if the line has an owner
     * @return boolean
     */
    public boolean hasOwner()
    {
        if (owner!=Player.NONE)
        {
            return true;
        }
        return false;
    }

    /**
     * claims the line if it has not been taken
     * @param owner
     */
    public void claim(Player owner)
    {
        this.owner=owner;
        for(Box b: boxes)
        {
            b.claim(owner);
        }
    }

    /**
     * adds the boxes associated to the array list
     * @param box
     */
    public void setBox(Box box)
    {
        boxes.add(box);
    }

    @Override
    public String toString()
    {
        if(((first.getColumn()==second.getColumn()) && (first.getRow()!=second.getRow())) && hasOwner())
        {
            return VERT_LINE;
        }
        else if((first.getColumn()!=second.getColumn()) && (first.getRow()==second.getRow())&& hasOwner())
        {
            return HORI_LINE;
        }
        else return EMPTY;
    }

    public boolean equals(Object other)
    {
        if(other instanceof Line)
        {
            Line l = (Line)other;
            return((this.first.equals(l.first))&&(this.second.equals(l.second)));

        }
        return false;
    }

}
