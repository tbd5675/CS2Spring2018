/**
 * Tate Dyer
 * Lab 02
 */
package game;

import java.util.ArrayList;

public class Box
{
    private int row;
    private int column;
    private Line top;
    private Line right;
    private Line bottom;
    private Line left;
    private Player owner;
    private Lines lines;

    /**
     * construtor for a box
     * @param r the row
     * @param c the column
     * @param lines collection of lines associated with a box
     */
    public Box(int r, int c, Lines lines)
    {

        row=r;
        column=c;
        top=lines.getLine(r,c, r,c+1);
        right=lines.getLine(r,c+1, r+1,c+1);
        bottom=lines.getLine(r+1,c,r+1,c+1);
        left=lines.getLine(r,c, r+1,c);
        this.lines=lines;
        owner=Player.NONE;

    }

    /**
     * get the row
     * @return row
     */
    public int getRow()
    {
        return row;
    }

    /**
     * get the column
     * @return column
     */
    public int getColumn()
    {
        return column;
    }

    /**
     * get the owner
     * @return owner
     */
    public Player getOwner()
    {
        return owner;
    }

    /**
     * gets the top line
     * @return top line
     */
    public Line getTopLine()
    {
        return top;
    }

    /**
     * gets the bottom line
     * @return bottom line
     */
    public Line getBottomLine()
    {
        return bottom;
    }

    /**
     * gets the right line
     * @return right line
     */
    public Line getRightLine()
    {
        return right;
    }

    /**
     * gets the left line
     * @return left line
     */
    public Line getLeftLine()
    {
        return left;
    }

    /**
     * if a boxes lines have all been claimed then owner claims the box
     * @param owner
     */
    public void claim(Player owner)
    {
        if(top.hasOwner() && bottom.hasOwner() && right.hasOwner() && left.hasOwner())
        {
            this.owner=owner;
        }
    }

    @Override
    public String toString()
    {
        return getOwner().getLabel();
    }

    @Override
    public boolean equals(Object other)
    {
        if(other instanceof Box)
        {
            Box b = (Box)other;
            return((this.row==b.row && this.column==b.column && this.owner==b.owner && this.left==b.left
            && this.right==b.right && this.top==b.top && this.bottom==b.bottom));

        }
        return false;
    }
}
