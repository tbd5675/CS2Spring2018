/* A few useful items are provided to you. You must write the rest. */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class TollRoadDatabase {
    /**
     * For printing floating point values in dollar/cents format. Example:
     * System.out.println( String.format( DOLLAR_FORMAT, 10.5 );  // $10.50
     */
    private static final String DOLLAR_FORMAT = "$%5.2f";
    private static final String SPEED_FORMAT = "%5.1f MpH";
    /**
     * HashMaps make for easy access of a TollRecord or multiple though the key tag
     */
    private HashMap<String, ArrayList<TollRecord>> complete;
    private HashMap<String, TollRecord> incomplete;
    /**
     * ArrayLists used to sort the tags for complete and incomplete reports so can be easily called when iterating though key value pairs
     */
    private ArrayList<String> complete_tags;
    private ArrayList<String> incomplete_tags;

    /**
     * Universal new line
     */
    private static final String NL = System.lineSeparator();

    /**
     * Conversion constant from minutes to hours
     */
    public static final double MINUTES_PER_HOUR = 60.0;

    /**
     * This toll road's speed limit, in miles per hour
     */
    public static final double SPEED_LIMIT = 65.0;


    /**
     * constructor for the database
     * @param eventFileName name of file to go through
     * @throws FileNotFoundException
     */
    public TollRoadDatabase(String eventFileName) throws FileNotFoundException
    {
        Scanner sc=new Scanner(new File(eventFileName));
        complete=new HashMap<>();
        incomplete=new HashMap<>();
        complete_tags=new ArrayList<>();
        incomplete_tags=new ArrayList<>();
        while(sc.hasNextLine())
        {
           String line=sc.nextLine();
           String[] values= line.split(",");
           enterEvent(values[1], Integer.parseInt(values[2]), Integer.parseInt(values[0]));

        }
        incomplete_tags.sort(String::compareTo);
        complete_tags.sort(String::compareTo);

    }

    /**
     * helps to go through the file and create the data structures
     * @param tag
     * @param exit
     * @param time
     */
    public void enterEvent(String tag, int exit, int time)
    {
        if(!incomplete.containsKey(tag))
        {
            incomplete.put(tag, new TollRecord(tag, exit, time));
            incomplete_tags.add(tag);
        }

        else
        {
            if(!complete.containsKey(tag))
            {
                complete.put(tag, new ArrayList<>());
                complete_tags.add(tag);
            }
            TollRecord tr= new TollRecord(tag, incomplete.get(tag).getOnExit(), incomplete.get(tag).getOnTime());
            complete.get(tag).add(tr);
            incomplete.remove(tag);
            incomplete_tags.remove(tag);
            tr.setOffExit(exit, time);
        }
    }

    /**
     * prints out the number of completed trips
     */
    public void summaryReport()
    {
        System.out.println("Number of complete trips: "+complete.size());
    }

    /**
     * prints out a report listing the vehicles that are still on the road. Print in order of licence tag.
     */
    public void onRoadReport()
    {
        System.out.println("On-Road Report");
        System.out.println("==============");
        for(String key:incomplete_tags)
        {
            System.out.println(incomplete.get(key).report());
        }

    }

    /**
     * prints out the billing report for the vehicles that completed trips. Lists the trips by vehicles tag
     * then by entry time. Toll charged is handled by getFare.
     */
    public void printBills()
    {
        System.out.println("Billing Information");
        System.out.println("==============");
        double total=0;
        for(String key:complete_tags)
        {
            for(int i=0; i<complete.get(key).size(); i++)
            {
                total=total+ complete.get(key).get(i).getFare();
                System.out.println(complete.get(key).get(i).report()+": "+String.format( DOLLAR_FORMAT, complete.get(key).get(i).getFare()));
            }
        }
        System.out.println("Total: "+String.format( DOLLAR_FORMAT, total));
    }

    /**
     * takes in a tag and returns amount they paid for all their tolls
     * @param tag
     * @return
     */
    public double bill(String tag)
    {
        double count=0;
        for(int i=0; i<complete.get(tag).size(); i++)
        {
            count=count+ complete.get(tag).get(i).getFare();
        }
        return count;
    }

    /**
     * lists cars going above the speed limit
     */
    public void speederReport()
    {
        System.out.println("Speeder Report");
        System.out.println("==============");
        double speed=0;
        double end=0;
        double start=0;
        int start_time=0;
        int end_time=0;
        for(String key:complete_tags)
        {
            for (int i = 0; i < complete.get(key).size(); i++)
            {
                end=TollSchedule.getLocation(complete.get(key).get(i).getOffExit());
                start=TollSchedule.getLocation(complete.get(key).get(i).getOnExit());
                end_time=complete.get(key).get(i).getOffTime();
                start_time=complete.get(key).get(i).getOnTime();
                speed=(Math.abs(end-start)/((end_time-start_time)/60.0));
                if(speed>SPEED_LIMIT)
                {
                    System.out.println("Vehicle " + key + ", starting at time " + complete.get(key).get(i).getOnTime() +
                            " from " + TollSchedule.getInterchange(complete.get(key).get(i).getOnExit())+" to "+
                            TollSchedule.getInterchange(complete.get(key).get(i).getOffExit())+" "+String.format( SPEED_FORMAT, speed));
                }
            }
        }
    }

    /**
     * print the summary info for a single customer specified by their tag and total due specified at end
     * @param tag
     */
    public void printCustSummary(String tag)
    {
        if(complete.containsKey(tag))
        {
            for(int i=0; i<complete.get(tag).size(); i++)
            {
                System.out.println(tag+" on #"+complete.get(tag).get(0).getOnExit()+", time "+
                        complete.get(tag).get(0).getOnTime()+"; off #"+complete.get(tag).get(0).getOffExit()+
                        ", time " + complete.get(tag).get(0).getOffTime()+": " + String.format( DOLLAR_FORMAT, bill(tag)));
            }
        }
    }

    /**
     * prints all toll records that include a specfic exit as their on or off point
     * @param exit
     */
    public void printExitActivity(int exit)
    {
        System.out.println("Exit "+exit+" Report");
        System.out.println("==============");
        for(String key:complete_tags)
        {
            for (int i = 0; i < complete.get(key).size(); i++)
            {
                if(complete.get(key).get(i).getOffExit()==exit || complete.get(key).get(i).getOnExit()==exit)
                {
                    System.out.println(complete.get(key).get(i).report());
                }
            }
        }
        for(String key:incomplete_tags)
        {
            if(incomplete.get(key).getOnExit()==exit)
            {
                System.out.println(incomplete.get(key).report());
            }
        }
    }
}
