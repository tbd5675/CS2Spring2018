import java.io.FileNotFoundException;
import java.util.Scanner;

public class TollReport {

    public static void main(String[] args) throws FileNotFoundException
    {
        if(args.length!=1)
        {
            System.exit(1);
        }
        TollRoadDatabase data= new TollRoadDatabase(args[0]);
        data.summaryReport();
        System.out.println("");
        data.onRoadReport();
        System.out.println("");
        data.speederReport();
        System.out.println("");
        data.printBills();
        System.out.println("");
        String letter="";
        while(!letter.equals("q"))
        {
            Scanner sc= new Scanner(System.in);
            System.out.println("'b' to see bill for license tag");
            System.out.println("'e' to see activity at an exit");
            System.out.println("'q' to quit");
            letter=sc.next();
            if(letter.equals("b"))
            {
                System.out.println("Enter a license tag.");
                String tag=sc.next();
                data.printCustSummary(tag);
            }
            else if(letter.equals("e"))
            {
                System.out.println("Enter an exit number.");
                int exit=sc.nextInt();
                data.printExitActivity(exit);
            }
            System.out.println("");
        }
        System.exit(0);
    }
}
