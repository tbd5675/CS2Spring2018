/* A few useful items are provided to you. You must write the rest. */

public class TollRecord implements Comparable<TollRecord>{

    /**
     * For printing toll records in reports
     * using {@link String#format(String, Object...)}
     */
    private static final String TOLL_RECORD_FORMAT = "[%11s] on #%2d, time %5d";
    private static final String OFF_FORMAT = "; off #%2d, time %5d";

    /**
     * Value of uninitialized integer fields in this record
     */
    public static final int UNINITIALIZED = -1;
    private String tag;
    private int onExit;
    private int onTime;
    private int offExit;
    private int offTime;

    /**
     * constructor for a toll record given tag and incoming exit and time
     * @param tag tag
     * @param onExit on exit
     * @param onTime on time
     */
    public TollRecord(String tag, int onExit, int onTime)
    {
      this.tag=tag;
      this.onExit=onExit;
      this.onTime=onTime;
      this.offExit=UNINITIALIZED;
      this.offTime=UNINITIALIZED;
    }

    /**
     * records the exit number and time when vehicle exits highway
     * @param offExit off exit
     * @param offTime off time
     */
    public void setOffExit(int offExit, int offTime)
    {
        this.offExit=offExit;
        this.offTime=offTime;
    }

    /**
     * accesses the tag
     * @return tag
     */
    public String getTag()
    {
        return tag;
    }

    /**
     * accesses the on exit
     * @return on exit
     */
    public int getOnExit()
    {
        return onExit;
    }

    /**
     * accesses the on time
     * @return on time
     */
    public int getOnTime()
    {
        return onTime;
    }

    /**
     * accesses the off exit
     * @return off exit
     */
    public int getOffExit()
    {
        return offExit;
    }

    /**
     * accesses the off time
     * @return off time
     */
    public int getOffTime()
    {
        return offTime;
    }

    /**
     * computes the toll paid by the vehicle once record complete
     * @return toll paid
     */
    public double getFare()
    {
        return TollSchedule.getFare(getOnExit(), getOffExit());
    }

    /**
     * two toll records are the sam eif all of their inner values are the same
     * @param o toll record to compare to
     * @return boolean value
     */
    @Override
    public boolean equals(Object o)
    {
        if(o instanceof TollRecord)
        {
            TollRecord t=(TollRecord)o;
            return(this.tag.equals(t.tag) && this.onTime==t.onTime);
        }
        return false;
    }

    /**
     * returns string representation of object
     * @return string representation
     */
    @Override
    public String toString()
    {
        if(getOffTime()==UNINITIALIZED)
        {
            return getTag()+"("+getOnExit()+","+getOnTime()+")";
        }
        return getTag()+"("+getOnExit()+","+getOnTime()+"), " +
                "("+getOffExit()+","+getOffTime()+")";
    }

    /**
     * return string representation of the object suitabe for display in report
     * @return string representation
     */
    public String report()
    {
        if(getOffTime()==UNINITIALIZED)
        {
            return getTag()+" on #"+getOnExit()+", time "+getOnTime();
        }
        return getTag()+" on #"+getOnExit()+", time "+getOnTime()+";" +
                " off #"+getOffExit()+", time "+getOffTime();
    }

    /**
     * return a hash code value for the object that conforms to the definition of equals
     * @return hash code value
     */
    @Override
    public int hashCode()
    {
        return this.getTag().hashCode()+Double.hashCode(this.getOnTime());
    }

    /**
     * the natural order comparison for toll records
     * @param t toll record to be compared to
     * @return a negative, 0 or positive number to determine order
     */
    public int compareTo(TollRecord t)
    {
        return this.getTag().compareTo(t.getTag()) +  this.getOnTime()-t.getOnTime();
    }

}
