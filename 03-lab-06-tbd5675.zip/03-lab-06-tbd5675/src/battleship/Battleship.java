package battleship;

//import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Battleship {

    public static final String ALL_SHIPS_SUNK="All ships sunk.";
    public static final String BAD_ARG_COUNT="Bad argument count.";
    public static final String MISSING_SETUP_FILE="Missing setup file.";
    public static final int MAX_DIM=20;
    public static final String DIM_TOO_BIG="Dimensions are too big.";
    public static final String BAD_CONFIG_FILE="Something went wrong reading text file.";
    public static final String PROMPT="Ready for user command.";
    public static final String WHITESPACE=" ";

    public static void main(String[] args)
    {
        try {
            if(args.length!=1)
            {
                System.out.println(BAD_ARG_COUNT);
            }
            else
            {
                FileReader file=new FileReader(args[0]);
                BufferedReader b= new BufferedReader(file);
                String line=b.readLine();
                String[] ln= line.split(WHITESPACE);
                int rows=Integer.parseInt(ln[0]);
                int columns=Integer.parseInt(ln[1]);
                if(rows>MAX_DIM || columns>MAX_DIM)
                {
                    System.out.println(DIM_TOO_BIG);
                }
                else
                {
                    Board board= new Board(rows,columns);
                    line=b.readLine();
                    while(line!=null)
                    {
                        ln= line.split(WHITESPACE);
                        int row=Integer.parseInt(ln[0]);
                        int column=Integer.parseInt(ln[1]);
                        String orientaion=ln[2];
                        int length=Integer.parseInt(ln[3]);
                        if(orientaion.equals("HORIZONTAL"))
                        {
                            Ship ship = new Ship(board, row, column, Ship.Orientation.HORIZONTAL, length);
                            board.addShip(ship);
                        }
                        else
                        {
                            Ship ship = new Ship(board, row, column, Ship.Orientation.VERTICAL, length);
                            board.addShip(ship);
                        }
                        line=b.readLine();
                    }
                    while(!board.allSunk())
                    {
                        System.out.println(PROMPT);
                        System.out.println("Enter h *row* *column* to hit, s *file* to save,  q to quit or ! to cheat.");
                        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                        String[] input=br.readLine().split(" ");
                        if(input[0].equals("q"))
                        {
                            System.exit(0);
                        }
                        else if(input[0].equals("s"))
                        {
                            ObjectOutputStream save=new ObjectOutputStream(new FileOutputStream(input[1]));
                            save.writeObject(board);
                            save.flush();
                            save.close();
                        }
                        else if(input[0].equals("h"))
                        {
                            int r=Integer.parseInt(input[1]);
                            int c=Integer.parseInt(input[2]);
                            board.getCell(r,c).hit();
                            board.display(System.out);

                        }
                        else if(input[0].equals("!"))
                        {
                            board.fullDisplay(System.out);
                        }
                        else
                        {
                            System.out.println("Not valid input. Try again.");
                        }
                        br.close();
                    }
                    System.out.println(ALL_SHIPS_SUNK);
                }
                b.close();
                file.close();
            }


        }
        catch (FileNotFoundException fnfe)
        {
            System.out.println(MISSING_SETUP_FILE);
        }
        catch (IOException ioe)
        {
            System.out.println(BAD_CONFIG_FILE);
        }
        catch (OverlapException oe) {
            System.out.println(oe.OVERLAP);
        }
        catch (OutOfBoundsException oobe) {
            System.out.println(oobe.PAST_EDGE);
        }
        catch (CellPlayedException cpe) {
            System.out.println(cpe.ALREADY_HIT);
        }
    }

}
