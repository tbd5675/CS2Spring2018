package battleship;

public class CellPlayedException extends BattleshipException {

    public static final String ALREADY_HIT="Space has already been hit.";

    public CellPlayedException(int row, int column)
    {
        super(row, column, ALREADY_HIT);
    }


}
