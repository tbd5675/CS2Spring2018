package battleship;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * The class to represent the grid of cells (squares).
 * A collection of ships is also kept so the Board
 * can be asked if the game is over.
 * The class is Serializable so that its instance can
 * be saved to a file in binary form using an
 * {@link java.io.ObjectOutputStream} and restored
 * with an {@link java.io.ObjectInputStream}.
 * Because the object holds references to all other
 * objects in the system, no other objects need to
 * be separately saved.
 */
public class Board implements Serializable {

    private int height;
    private int width;
    private Cell cells[][];
    private ArrayList<Ship> ships;

    /**
     * constructor for the board based off a matrix
     * @param height how tall
     * @param width how wide
     */
    public Board(int height, int width)
    {
        this.height=height;
        this.width=width;
        cells=new Cell[height][width];
        for(int i=0; i<height; i++)
        {
            for(int j=0; j<width; j++)
            {
                cells[i][j]=new Cell(i, j);
            }
        }
        ships=new ArrayList<>();
    }

    /**
     * get the height
     * @return the height
     */
    public int getHeight()
    {
        return height;
    }

    /**
     * get the width
     * @return the width
     */
    public int getWidth()
    {
        return width;
    }

    /**
     * Fetch the Cell object at the given location.
     * @param row row number (0-based)
     * @param column column number (0-based)
     * @return the Cell created for this position on the board
     * @throws OutOfBoundsException if either coordinate is negative or too high
     */
    public Cell getCell(int row, int column) throws OutOfBoundsException
    {
        if(row<height && column<width)
        {
            return cells[row][column];
        }
        else {
            throw new OutOfBoundsException(row,column);
        }

    }

    /**
     * what the board is in words
     * @return string representation
     */
    public String toString()
    {
        return height+" by "+width+" board";
    }

    /**
     * displays the board without cheating and changes as the player hits
     * @param out stream
     * @throws OutOfBoundsException if the height or width is off the matrix
     */
    public void display(PrintStream out) throws OutOfBoundsException
    {
        System.out.print(" ");
        for(int i=0; i<width; i++)
        {
            System.out.print(" "+i);
        }
        for(int j=0; j<height; j++)
        {
            System.out.println("");
            System.out.print(j);
            for(int k=0; k<width; k++)
            {
                System.out.print(" "+getCell(j,k).displayHitStatus());
            }
        }
        System.out.println("");
    }

    /**
     * displays the full board by cheating and showing all the ships
     * @param out stream
     * @throws OutOfBoundsException if the height or width is off the matrix
     */
    public void fullDisplay(PrintStream out) throws OutOfBoundsException
    {
        System.out.print(" ");
        for(int i=0; i<width; i++)
        {
            System.out.print(" "+i);
        }

        for(int j=0; j<height; j++)
        {
            System.out.println("");
            System.out.print(j);
            for(int k=0; k<width; k++)
            {
                System.out.print(" "+getCell(j,k).displayChar());
            }
        }
        System.out.println("");
    }

    /**
     * Add a ship to the board. The only current reason that the
     * board needs direct access to the ships is to poll them
     * to see if they are all sunk and the game is over.
     * @see Cell#putShip(Ship)
     * @param ship the as-yet un-added ship
     * @rit.pre This ship has already informed the Cells of the board
     *    that are involved.
     */
    // TODO addShip GOES HERE
    public void addShip(Ship ship)
    {
        ships.add(ship);
    }

    /**
     * checks if all the ships are sunk
     * @return true or false
     */
    public boolean allSunk()
    {
       if(ships.isEmpty())
       {
           return true;
       }
       return false;
    }

}
