package battleship;

public class OutOfBoundsException extends BattleshipException {

    public static final String PAST_EDGE="The space input is out of bounds on the grid.";

    public OutOfBoundsException(int row, int column)
    {
        super(row, column, PAST_EDGE);
    }
}
