package battleship;

import java.io.Serializable;

/**
 * A single spot on the Battleship game board.
 * A cell knows if there is a ship on it, and it remember
 * if it has been hit.
 */
public class Cell implements Serializable {

    /** Character to display for a ship that has been entirely sunk */
    public static final char SUNK_SHIP_SECTION = '*';

    /** Character to display for a ship that has been hit but not sunk */
    public static final char HIT_SHIP_SECTION = '☐';

    /** Character to display for a water cell that has been hit */
    public static final char HIT_WATER = '.';

    /**
     * Character to display for a water cell that has not been hit.
     * This character is also used for an unhit ship segment.
     */
    public static final char PRISTINE_WATER = '_';

    /**
     * Character to display for a ship section that has not been
     * sunk, when revealing the hidden locations of ships
     */
    public static final char HIDDEN_SHIP_SECTION = 'S';

    private int row;
    private int column;
    private char hitStatus;
    private Ship ship;

    /**
     * Constructor for a cell
     * @param row row location
     * @param column column location
     */
    public Cell(int row, int column)
    {
        this.row=row;
        this.column=column;
        hitStatus=PRISTINE_WATER;
        ship=null;
    }

    /**
     * Place a ship on this cell. Of course, ships typically cover
     * more than one Cell, so the same ship will usually be passed
     * to more than one Cell's putShip method.
     * @param ship the ship that is to be on this Cell
     * @throws OverlapException if there is already a ship here.
     */
    public void putShip(Ship ship) throws OverlapException
    {
        if(this.ship==null)
        {
            this.ship = ship;
            hitStatus = HIDDEN_SHIP_SECTION;
        }
        else {
            throw new OverlapException(row, column);
        }
    }

    /**
     * cell takes hit and changes its status and if hits ship keepd track of it by calling the ship hit function
     * @throws CellPlayedException if the place has already been hit
     * @throws OutOfBoundsException if the hit is out of bounds
     */
    public void hit() throws CellPlayedException, OutOfBoundsException
    {
        if(hitStatus==HIT_SHIP_SECTION || hitStatus==HIT_WATER || hitStatus==SUNK_SHIP_SECTION)
        {
            throw new CellPlayedException(row, column);
        }
        else if(hitStatus==HIDDEN_SHIP_SECTION)
        {
            ship.hit();
            if(ship.isSunk())
            {
                hitStatus=SUNK_SHIP_SECTION;

            }
            else
            {
                hitStatus=HIT_SHIP_SECTION;
            }
        }
        else if(hitStatus==PRISTINE_WATER)
        {
            hitStatus=HIT_WATER;
        }
    }

    /**
     * returns the character of the hit status to be used in the display
     * @return character
     */
    public char displayHitStatus()
    {
        if(hitStatus==HIDDEN_SHIP_SECTION)
        {
            return PRISTINE_WATER;
        }
        return hitStatus;
    }

    /**
     * returns the character of the hit status to be used in the display and does not hide if a ship is present- used in the cheat
     * @return character
     */
    public char displayChar()
    {
        return hitStatus;
    }

    /**
     * helper to change the other cells of a ship once it is sunk to also be sunk on the display
     */
    public void setSunkShipSection()
    {
        hitStatus=SUNK_SHIP_SECTION;
    }

}
