package battleship;

public class OverlapException extends BattleshipException{

    public static final String OVERLAP="You tried to place a ship where there already is one.";

    public OverlapException(int row, int column)
    {
        super(row, column, OVERLAP);
    }
}
