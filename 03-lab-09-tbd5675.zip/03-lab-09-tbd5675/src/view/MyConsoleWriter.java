package view;

import controller.ConsoleWriter;
import javafx.scene.Node;
import javafx.scene.control.Label;

public class MyConsoleWriter implements ConsoleWriter{
    private Label console;

    /**
     * Constructor for the console writer
     * @param console
     */
    public MyConsoleWriter(Label console)
    {
        this.console = console;
    }

    /**
     * Write a message to the console.
     *
     * @param text The message to write
     */
    public void write(String text)
    {
        console.setText(text);
    }

}
