package view;

import controller.BattleShip;
import controller.Observer;
import controller.ShipData;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.Location;

/**
 * The provided javadocs only includes items that are
 * inherited from Application. All of which you will
 * not need to implement except for start which is
 * already provided below. Please replace this comment
 * block with something useful when you create your
 * implementation.
 */
public class GameBoard extends Application implements Observer<ShipData>{
    private BattleShip battleship;
    private MyConsoleWriter console;
    private GridPane player;
    private GridPane target;

    public void start(Stage stage) {
        Label text= new Label("Console");
        console= new MyConsoleWriter(text);
        battleship = new BattleShip(console);
        BorderPane pane = new BorderPane();
        target= new GridPane();
        VBox left=setTarget(target);
        player= new GridPane();
        VBox right=setPlayer(player);
        pane.setLeft(left);
        pane.setRight(right);
        pane.setBottom(text);
        pane.setPrefSize(800, 600);
        pane.setStyle("-fx-padding: 10;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 2;" +
                "-fx-border-insets: 5;" +
                "-fx-border-radius: 5;" +
                "-fx-border-color: blue;");
        battleship.addShips(this);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.setTitle("BattleShip");
        stage.show();
    }

    /**
     * makes the target pane
     * @param g1 grid passed in
     * @return vbox of title and pane
     */
    public VBox setTarget(GridPane g1)
    {
        for(int x=0; x<10;x++)
        {
            for(int y=1; y<=10;y++)
            {
                Button b1=new Button();
                Location loc= new Location(x,y);
                b1.setOnAction(e->battleship.attack(loc));
                b1.setOnAction(e->b1.setStyle("-fx-background-color: #dc143c"));
                b1.setPrefSize(35,35);
                b1.setStyle("-fx-background-color: #00bfff;" +
                        " -fx-border-color: #b0c4de;" +
                        " -fx-border-width: 3px;");
                g1.add(b1,x,y);
            }
        }
        Label target=new Label("           Target Pane");
        target.setFont(new Font("Arial", 30));
        VBox left= new VBox();
        left.getChildren().addAll(target, g1);
        return left;
    }

    /**
     * makes the player pane
     * @param g2 grid passed in
     * @return vbox of title and pane
     */
    public VBox setPlayer(GridPane g2)
    {
        for(int x=0; x<10;x++)
        {
            for(int y=1; y<=10;y++)
            {
                Button b2=new Button();
                b2.setPrefSize(35,35);
                b2.setStyle("-fx-background-color: #00bfff;" +
                        " -fx-border-color: #b0c4de; " +
                        "-fx-border-width: 3px;");
                g2.add(b2,x,y);
            }
        }
        Label player=new Label("           Player Pane");
        player.setFont(new Font("Arial", 30));
        VBox right= new VBox();
        right.getChildren().addAll(player, g2);
        return right;
    }

    /**
     * updates the ships on the game board
     * @param pushValue The value that will be pushed to the observer
     */
    @Override
    public void update(ShipData pushValue)
    {
        Location loc= pushValue.getBowLocation();
        int x=loc.getCol();
        int y=loc.getRow();
        ShipData.Orientation orientation=pushValue.getOrientation();
        int length=pushValue.getSize();
        if(orientation.equals(ShipData.Orientation.HORIZONTAL))
        {
            for(int i=x; i<x+length; i++)
            {
                Button b=(Button)getNodeFromGridPane(this.player, i, y);
                b.setStyle("-fx-background-color: #b0c4de; ");
            }
        }
        else if(orientation.equals(ShipData.Orientation.VERTICAL))
        {
            for(int j=y; j<y+length; j++)
            {
                Button b=(Button)getNodeFromGridPane(this.player, x, j);
                b.setStyle("-fx-background-color: #b0c4de; ");
            }
        }
    }

    /**
     * gets the button in the grid pane
     * @param gridPane pane
     * @param col column
     * @param row row
     * @return button
     */
    private Node getNodeFromGridPane(GridPane gridPane, int col, int row) {
        for (Node node : gridPane.getChildren()) {
            if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
                return node;
            }
        }
        return null;
    }
}

