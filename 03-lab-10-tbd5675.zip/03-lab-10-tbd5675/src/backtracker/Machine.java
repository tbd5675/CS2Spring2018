package backtracker;

public class Machine {
    private int id;
    private int finishTime;
    //private List<Item> items;

    public Machine(int id, int finishTime)
    {
        this.id=id;
        this.finishTime=finishTime;
    }

    public int getID()
    {
        return id;
    }

    public int getFinishTime()
    {
        return finishTime;
    }

    public void getItems()
    {

    }


}
