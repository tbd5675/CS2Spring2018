package backtracker;

import scheduling.Job;

import java.util.Collection;
import java.util.Map;

public class JobSchedulingConfig implements Configuration {

    private Map<String, Job> jobs;
    private int num1;
    private int num2;
    public JobSchedulingConfig(Map<String, Job> jobs, int num1, int num2)
    {
        this.jobs=jobs;
        this.num1=num1;
        this.num2=num2;
    }

    @Override
    public Collection<Configuration> getSuccessors() {
        return null;
    }

    @Override
    public boolean isValid() {
        return false;
    }

    @Override
    public boolean isGoal() {
        return false;
    }
}
