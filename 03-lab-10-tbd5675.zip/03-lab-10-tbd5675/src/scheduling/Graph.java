package scheduling;

import javafx.scene.Node;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * Class representing the dependency of jobs
 */
public class Graph {
    /**
     *Jobs is represented using a map (dictionary)
     */
    protected Map<String, Job> jobs;

    /**
     * Construct a directed graph by reading data from a file
     * Perform acyclicity test. If the graph is not acyclic,
     * print a proper message "Cyclic. No solution" and exit the program.
     * Set the rank of all nodes.
     * Display the graph
     * @param filename The name of a file containing node/job's name, costs, and dependency
     */
    public Graph(String filename) {
        try (Scanner in = new Scanner(new File(filename))) {
            //0. Construct the graph
            jobs = new HashMap<>();

            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] fields = line.split(",");
                int[] costs = {Integer.parseInt(fields[1]),
                        Integer.parseInt(fields[2]), Integer.parseInt(fields[3])};
                if (!jobs.containsKey(fields[0])) {

                    jobs.put(fields[0], new Job(fields[0], costs));

                }
                else{
                    jobs.get(fields[0]).setCosts(costs);
                }
                Job job = jobs.get(fields[0]);
                for (int i=4; i<fields.length; ++i) {
                    if (!jobs.containsKey(fields[i])) {
                        jobs.put(fields[i], new Job(fields[i]));
                    }
                    Job neighbor = jobs.get(fields[i]);
                    job.addOutNeighbor(neighbor);
                    neighbor.addInNeighbor(job);
                }

            }
        }
        catch(FileNotFoundException ex){
            System.out.println(ex);
        }

        //1. Acyclicity test
        if (!isAcyclic()) {
            System.out.println("Graph is cyclic. No solution!");
            System.exit(0);
        }
        System.out.println("Graph is acyclic.");


        //2. Set rank of each node in graph
        setRankBFS();
    }

    /**
     * @return a string string representation of the jobs.
     */
    @Override
    public String toString() {
        String result = "";
        for (String name : jobs.keySet()) {
            result = result + jobs.get(name) + "\n";
        }
        return result;
    }

    /**
     * @return the graph of jobs
     */
    public Map<String, Job> getJobs(){
        return this.jobs;
    }



    /**
     Perform the following peeling process in a DFS manner starting from each start node.
     Repeat until there is no start node left:
     Remove a start node with its edges from the graph.
     * @return true iff the resulted graph is emoty
     */
    public boolean isAcyclic()
    {
        Map<String, Job> map=this.getJobs();
        Collection<Job> jobs=map.values();
        Map<String, Job> copyJobs=new HashMap<>();
        for(Job j: jobs)
        {
            Job cop = new Job(j);
            copyJobs.put(cop.getName(), cop);
        }
        jobs=copyJobs.values();
        for(Job j: jobs)
        {
            if(j.isStartNode())
            {
                copyJobs=isAcyclicHelper(copyJobs, j);
            }
        }
        return copyJobs.isEmpty();
    }

    public static Map<String,Job> isAcyclicHelper(Map<String, Job> map, Job job)
    {
        Collection<Job> inN=job.getInNeighbors();
        Collection<Job> outN=job.getOutNeighbors();
        map.remove(job.getName());
        for(Job j: inN)
        {
            j.removeInNeighbor(j);
        }
        for(Job j: outN)
        {
            if(j.isStartNode())
            {
                return isAcyclicHelper(map, j);
            }
        }
        return map;
    }


    /**
     * Set the rank of each nodes in this graph using BFS.
     * The rank of a node is defined as the maximum path length from any staring node to the node.
     */
    public void setRankBFS()
    {
        int rank;
        int c=0;
        for(Job j: jobs.values())
        {
            if(j.isStartNode())
            {
                j.setRank(1);
            }
            else
            {
                for(Job g: jobs.values())
                {
                    if(g.isStartNode())
                    {
                        c=helperBFS(g, j, Integer.MAX_VALUE);
                    }
                    g.setRank(c);
                }

            }
        }
    }

    public int helperBFS(Job startNode, Job target, int c)
    {
        int count=c;
        if(startNode.getOutNeighbors().contains(target))
        {
            count++;
        }
        else
        {
            for(Job j: startNode.getOutNeighbors())
            {
                if(j.isStartNode())
                {
                    int helpc=helperBFS(j, target, c+1);
                    if(helpc<count)
                    {
                        count=helpc;
                    }
                }
            }
        }
        return count;
    }

    /**
     * Test graph analysis before backtracking
     * @param args file name
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java Graph graph-file");
        } else {

            Graph analysis = new Graph(args[0]);
            System.out.println("Ranks are set.");
            System.out.println(analysis);
        }
    }
}

