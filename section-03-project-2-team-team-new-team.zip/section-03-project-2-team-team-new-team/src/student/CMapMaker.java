package student;

import jdk.nashorn.api.tree.Tree;
import model.*;

import java.io.*;
import java.util.*;

/**
 * Creates the Map
 */

public class CMapMaker implements MapMaker {

    /**
     * Loads a {@linkplain RailroadMap map} using the data in the given
     * {@linkplain InputStream input stream}.
     *
     * @param in The {@link InputStream} used to read the {@link RailroadMap
     * map} data.
     * @return The {@link RailroadMap map} read from the given
     * {@link InputStream}.
     *
     * @throws RailroadBaronsException If there are any problems reading the
     * data from the {@link InputStream}.
     */
    @Override
    public RailroadMap readMap(InputStream in) throws RailroadBaronsException {
        Scanner scanner = new Scanner(in);
        String newLine;
        String[] trackArgs;
        CSpace space;
        CStation station;
        CRoute route;
        Orientation temport;
        int routeLength;

        HashMap<Integer, CStation> stations = new HashMap<>();
        LinkedList<Route> routes = new LinkedList<Route>();
        /*
         * Reads the file to the ##ROUTES## and adds each station to a Hashmap.
         */
        while(scanner.hasNextLine()){
            newLine = scanner.nextLine();
            if(newLine.equals("##ROUTES##")){break;}

            trackArgs = newLine.split(" ");
            //space = new CSpace(Integer.parseInt( trackArgs[1] ),Integer.parseInt( trackArgs[2] ));
            //station = new CStation(trackArgs[0], space);
            stations.put(Integer.parseInt(trackArgs[0]), new CStation(trackArgs[3],new CSpace(Integer.parseInt(trackArgs[1]),Integer.parseInt(trackArgs[2]))));

        }
        /*
         * Reads the rest of the file and adds each route to a HashSet.
         */
        while(scanner.hasNextLine()){
            newLine = scanner.nextLine();
            trackArgs = newLine.split(" ", 4);
            int i1 = Integer.parseInt(trackArgs[0]);
            int i2 = Integer.parseInt(trackArgs[1]);

            if(stations.containsKey(i1) && stations.containsKey(i2)){
                CStation station1 = stations.get(i1);
                CStation station2 = stations.get(i2);
                if(station1.getRow() == station2.getRow()){
                    temport = Orientation.HORIZONTAL;
                    routeLength = Math.abs( station1.getCol() - station2.getCol());
                }
                else {
                    temport = Orientation.VERTICAL;
                    routeLength = Math.abs( station1.getRow() - station2.getRow());

                }
                route = new CRoute(station1, station2, temport, routeLength);
                routes.add(route);

            }else{
                Exception e = new RailroadBaronsException("idk this is the wrong exception though. its in cMapMaker");
                try {
                    throw(e);
                } catch (Exception e1) {
                    System.err.println("Invalid input file");
                }
            }
        }

        int mapColSize = getColSize(stations);
        int mapRowSize = getRowSize(stations);

        CRailroadMap newMap = new CRailroadMap(mapRowSize, mapColSize, routes);

        return newMap;
    }

    /**
     * Returns the largest column
     * @param map
     * @return
     */
    private int getColSize(HashMap<Integer, CStation> map){
        int x = 0;

        for(CStation i : map.values()){
            if(x < i.getCol()){
                x = i.getCol();
            }
        }
        return x;
    }

    /**
     * Returns the largest row
     * @param map
     * @return
     */
    private int getRowSize(HashMap<Integer, CStation> map){
        int x = 0;
        for(CStation i : map.values()){
            if(x < i.getRow()){
                x = i.getRow();
            }
        }
        return x;
    }

    /**
     * Writes the specified {@linkplain RailroadMap map} in the Railroad
     * Barons map file format to the given {@linkplain OutputStream output
     * stream}. The written map should include an accurate record of any
     * routes that have been claimed, and by which {@linkplain Baron}.
     *
     * @param map The {@link RailroadMap map} to write out to the
     * {@link OutputStream}.
     * @param out The {@link OutputStream} to which the
     * {@link RailroadMap map} data should be written.
     *
     * @throws RailroadBaronsException If there are any problems writing the
     * data to the {@link OutputStream}.
     */
    @Override
    public void writeMap(RailroadMap map, OutputStream out) throws RailroadBaronsException {
        BufferedWriter bw;
        Writer outWrite = new OutputStreamWriter(out);
        bw = new BufferedWriter(outWrite);
        Set<Route> routes = (TreeSet<Route>) map.getRoutes();
        Map<Integer, Station> stationMap = new TreeMap<>();
        Map<String, Integer> stationNameMap = new TreeMap<>();
        int i = 0;

        String outLine;

        /*
         * creates stations map to be written to file with
         */
        for(Route route : routes){
            Station first = route.getDestination();
            if(!stationMap.values().contains(first)){
                stationMap.put(i, first);
                stationNameMap.put(first.getName(), i);
                i++;
            }

            Station second = route.getOrigin();
            if(!stationMap.containsValue(second)){
                stationNameMap.put(first.getName(), i);
                stationMap.put(i, second);
                i++;
            }
        }

        /*
         * writes stations to file.
         */

        i = stationMap.size();
        int x = 0;
        while(i > x){

            Station tempStation = stationMap.get(x);
            int col = tempStation.getCol();
            int row = tempStation.getRow();
            int stationNumber = x;
            String stationName = tempStation.getName();


            outLine = ""+ stationNumber + " " + row + " " + col + " " + stationName + "\n";
            try {
                bw.write(outLine);
            } catch (IOException e) {
                throw new RailroadBaronsException("Error writing station to file");
            }
            x++;
        }
        try {
            bw.write("##ROUTES##");
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*
         * writes the routes to the file.
         */
        for(Route route : routes){
            int originNumber = stationNameMap.get(route.getOrigin().getName());
            int destNumber = stationNameMap.get(route.getOrigin().getName());
            outLine = "" + originNumber + " " + destNumber + " " + route.getBaron();
            try{
                bw.write(outLine);
            } catch (IOException e) {
                throw new RailroadBaronsException("Error writing route to file");

            }
        }



    }

}
