package student;

import model.Card;
import model.Deck;

import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class CDeck implements Deck {
    private Stack<Card> cards;

    /**
     * makes a deck of 20 of each playable card and shuffles
     */
    public CDeck()
    {
        cards=new Stack<>();
        reset();
    }

    /**
     * resets deck to initial state shuffled
     */
    @Override
    public void reset()
    {
        for(int x=0; x<20; x++)
        {
            cards.add(Card.RED);
            cards.add(Card.BLACK);
            cards.add(Card.ORANGE);
            cards.add(Card.GREEN);
            cards.add(Card.YELLOW);
            cards.add(Card.WHITE);
            cards.add(Card.BLUE);
            cards.add(Card.PINK);
            cards.add(Card.WILD);
        }
        Collections.shuffle(cards);
    }

    /**
     *draws a cared from deck and returns it
     * @return card
     */
    @Override
    public Card drawACard()
    {
        return cards.pop();
    }

    /**
     * number of cards still in the deck
     * @return num cards
     */
    @Override
    public int numberOfCardsRemaining()
    {
        return cards.size();
    }
}
