package student;

import model.*;

/**
 * Represents a track segment on the map.
 * Tracks combine to form routes.
 * @author Noah Britton
 */
public class CTrack implements Track {
    private Orientation orientation;
    private Baron baron;
    private Route route;
    private Space space;
    /**
     * Returns the orientation of the track; either
     * {@linkplain Orientation#HORIZONTAL horizontal} or
     * {@linkplain Orientation#VERTICAL vertical}. This is based on the
     * {@linkplain Orientation orientation} of the {@linkplain Route route}
     * that contains the track.
     *
     * @return The {@link Orientation} of the {@link Track}; this is the same
     * as the {@link Orientation} of the {@link Route} that contains the
     * track.
     */
    public CTrack(Space space, Orientation orientation, Baron baron, Route route){
        this.space = space;
        this.orientation = orientation;
        this.route = route;
        this.baron = baron;

    }

    @Override
    public Orientation getOrientation() {
        return this.orientation;
    }

    /**
     * Returns the current {@link Baron owner} of this track, either
     * {@linkplain Baron#UNCLAIMED unclaimed} if the track has not been
     * claimed, or the {@linkplain Baron owner} that corresponds with the
     * color of the player that successfully claimed the
     * {@linkplain Route route} of which this track is a part.
     *
     * @return The {@link Baron} that has claimed the route of which this
     * track is a part.
     */
    @Override
    public Baron getBaron() {
        return this.baron;
    }

    /**
     * Returns the {@linkplain Route route} of which this
     * {@linkplain Track track} is a part.
     *
     * @return The {@link Route} that contains this track.
     */
    @Override
    public Route getRoute() {
        return this.route;
    }

    /**
     * Returns this station's space's row
     * @return
     */
    @Override
    public int getRow() {
        return space.getRow();
    }

    /**
     * Returns this station's space's column
     * @return
     */
    @Override
    public int getCol() {
        return space.getCol();
    }

    /**
     * Returns true if the other track is occupying the same physical location
     * in the map as this space.
     *
     * @param otherSpace The other track to which this space is being compared for
     *              collocation.
     *
     * @return True if the two track are in the same physical location (row
     * and column) in the map; false otherwise.
     */
    @Override
    public boolean collocated(Space otherSpace) {
        return space.collocated(otherSpace);
    }

}
