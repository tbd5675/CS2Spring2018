package student;

import model.Space;
import model.Station;

/**
 * Represents the train stations on the map and is at the end of the track.
 *
 */
public class CStation implements Station {
    private String name;
    private Space space;

    public CStation(String name, Space space){
        this.name = name;
        this.space = space;
    }

    /**
     * Returns ths stations name
     * @return
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     * Returns this station's space's row
     * @return
     */
    @Override
    public int getRow() {
        return space.getRow();
    }

    /**
     * Returns this station's space's column
     * @return
     */
    @Override
    public int getCol() {
        return space.getCol();
    }
    /**
     * Returns true if the other station is occupying the same physical location
     * in the map as this space.
     *
     * @param otherSpace The other space to which this space is being compared for
     *              collocation.
     *
     * @return True if the two spaces are in the same physical location (row
     * and column) in the map; false otherwise.
     */
    @Override
    public boolean collocated(Space otherSpace) {
        return space.collocated(otherSpace);
    }
}
