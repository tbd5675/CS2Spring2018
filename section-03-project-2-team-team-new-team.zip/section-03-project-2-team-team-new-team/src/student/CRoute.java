package student;

import model.*;

import java.util.LinkedList;
import java.util.List;

public class CRoute implements Route {
    private Baron baron;
    private Station stationStart;
    private Station stationEnd;
    private Orientation orientation;
    private List<Track> tracks;
    private int length;
    private boolean isClaimed;

    /**
     * constructor for a route
     * @param stationStart start
     * @param stationEnd end
     * @param orientation horiz or vert
     * @param length how long
     */
    public CRoute(Station stationStart, Station stationEnd, Orientation orientation, int length)
    {
        baron=Baron.UNCLAIMED;
        this.stationStart=stationStart;
        this.stationEnd=stationEnd;
        this.orientation=orientation;
        tracks= new LinkedList<>();
        if(orientation == Orientation.HORIZONTAL){
            for(int i = 0; i < length; i ++){
                tracks.add(new CTrack(new CSpace(stationStart.getRow(),stationStart.getCol()+i),orientation,Baron.UNCLAIMED,this));
            }
        }
        else{
            for(int i = 0; i < length; i ++){
                tracks.add(new CTrack(new CSpace(stationStart.getRow()+i,stationStart.getCol()),orientation,Baron.UNCLAIMED,this));
            }
        }
        this.length=length;
        isClaimed=false;
    }

    /**
     * Returns the Baron that has claimed this route
     * @return baron
     */
    @Override
    public Baron getBaron()
    {
        return baron;
    }

    /**
     *Returns the station at the beginning of this route
     * @return start
     */
    @Override
    public Station getOrigin()
    {
        return stationStart;
    }

    /**
     *Returns the station at the end of this route
     * @return end
     */
    @Override
    public Station getDestination()
    {
        return stationEnd;
    }

    /**
     *Returns the orientation of this route
     * @return horizontal or vertical
     */
    @Override
    public Orientation getOrientation()
    {
        return orientation;
    }

    /**
     *The set of tracks that make up this route
     * @return tracks
     */
    @Override
    public List<Track> getTracks()
    {
        return tracks;
    }

    /**
     *returns length of route
     * @return length of route
     */
    @Override
    public int getLength()
    {
        return length;
    }

    /**
     * Returns the number of points that this route is worth
     * @return number of points
     */
    @Override
    public int getPointValue()
    {
        if(length==0)
        {
            return 0;
        }
        else if(length==1)
        {
            return 1;
        }
        else if(length==2)
        {
            return 2;
        }
        else if(length==3)
        {
            return 4;
        }
        else if(length==4)
        {
            return 7;
        }
        else if(length==5)
        {
            return 10;
        }
        else if(length==6)
        {
            return 15;
        }
        else
        {
            return 5*(length-3);
        }

    }

    /**
     * Returns true if the route covers the ground at the location of the specified space and false otherwise
     * @param space The {@link Space} that may be in this route.
     *
     * @return true or false if included in route
     */
    @Override
    public boolean includesCoordinate(Space space)
    {
        for(Track t: tracks) {
            if(t.getRow() == space.getRow() && t.getCol() == space.getCol()){
                return true;
            }
        }
        return false;
    }

    /**
     * Attempts to claim the route on behalf of the specified Baron
     * @param claimant The {@link Baron} attempting to claim the route. Must
     *                 not be null or {@link Baron#UNCLAIMED}.
     * @return
     */
    @Override
    public boolean claim(Baron claimant) {
        if(claimant == Baron.UNCLAIMED){
            return isClaimed;
        }
        if(!isClaimed)
        {
            baron=claimant;
            isClaimed = true;
            return true;

        }
        return false;
    }

}
