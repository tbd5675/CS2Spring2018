package student;

import model.*;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class RailroadBaronsLonelyEdition extends CRailroadBarons {
    protected List<RailroadBaronsObserver> observers;
    public Queue<Player> players;
    public Deck deck;
    protected RailroadMap railroadMap;
    protected Graph<CStation> graph;
    private CStation north;
    private CStation south;
    private CStation west;
    private CStation east;


    public RailroadBaronsLonelyEdition()
    {
        observers = new LinkedList<RailroadBaronsObserver>();
        players = new LinkedList<Player>();
        deck = null;
        railroadMap = null;
        graph=null;
        north=null;
        south=null;
        east=null;
        west=null;
    }

    /**
     *
     Adds a new observer to the collection of observers that will be notified when the state of the game changes
     * @param observer The {@link RailroadBaronsObserver} to add to the
     */
    @Override
    public void addRailroadBaronsObserver(RailroadBaronsObserver observer) {
        observers.add(observer);
    }

    /**
     * Removes the observer from the collection of observers that will be notified when the state of the game changes
     * @param observer The {@link RailroadBaronsObserver} to remove.
     */
    @Override
    public void removeRailroadBaronsObserver(RailroadBaronsObserver observer) {
        observers.remove(observer);
    }

    /**
     *Starts a new Railroad Barons game with the specified map and a default deck of cards
     * @param map The {@link RailroadMap} on which the game will be played.
     */
    @Override
    public void startAGameWith(RailroadMap map)
    {
        deck=new CDeck();
        this.railroadMap = map;
        if(players.size() > 0) {
            for(Player p: players){
                p.reset(deck.drawACard(),deck.drawACard(),deck.drawACard(),deck.drawACard());
            }
        }
        else {
            Player player1 = new CPlayer(Baron.RED, deck, this);
            players.add(player1);
            ComputerPlayer player2 = new ComputerPlayer(Baron.BLUE, deck, this);
            players.add(player2);
            ComputerPlayer player3 = new ComputerPlayer(Baron.YELLOW, deck, this);
            players.add(player3);
            ComputerPlayer player4 = new ComputerPlayer(Baron.GREEN, deck, this);
            players.add(player4);
            for (Player p : players) {
                for (RailroadBaronsObserver o : observers) {
                    p.addPlayerObserver((PlayerObserver) o);
                }
            }
        }
        players.peek().startTurn(new CPair(deck.drawACard(),deck.drawACard()));
        for(RailroadBaronsObserver r: observers){
            r.turnStarted(this,players.peek());
        }
        graph=makeGraph();
    }

    /**
     *Starts a new Railroad Barons game with the specified map and deck of cards
     * @param map The {@link RailroadMap} on which the game will be played.
     * @param deck The {@link Deck} of cards used to play the game. This may
     *             be ANY implementation of the {@link Deck} interface,
     *             meaning that a valid implementation of the
     *             {@link RailroadBarons} interface should use only the
     */
    @Override
    public void startAGameWith(RailroadMap map, Deck deck) {
        this.railroadMap = map;
        this.deck = deck;
            if (players.size() > 0) {
                for (Player p : players) {
                    p.reset(deck.drawACard(), deck.drawACard(), deck.drawACard(), deck.drawACard());
                }
            } else {
                Player player1 = new CPlayer(Baron.RED, deck, this);
                players.add(player1);
                ComputerPlayer player2 = new ComputerPlayer(Baron.BLUE, deck, this);
                players.add(player2);
                ComputerPlayer player3 = new ComputerPlayer(Baron.YELLOW, deck, this);
                players.add(player3);
                ComputerPlayer player4 = new ComputerPlayer(Baron.GREEN, deck, this);
                players.add(player4);
                for (Player p : players) {
                    for (RailroadBaronsObserver o : observers) {
                        p.addPlayerObserver((PlayerObserver) o);
                    }
                }
            }
            players.peek().startTurn(new CPair(deck.drawACard(), deck.drawACard()));
            for (RailroadBaronsObserver r : observers) {
                r.turnStarted(this, players.peek());
            }
            graph = makeGraph();
    }

    /**
     *Returns the map currently being used for play
     * @return railroad map
     */
    @Override
    public RailroadMap getRailroadMap() {
        return railroadMap;
    }

    /**
     * Returns the number of cards that remain to be dealt in the current game's deck
     * @return num cards
     */
    @Override
    public int numberOfCardsRemaining() {
        return deck.numberOfCardsRemaining();
    }

    /**
     * Returns true iff the current player can claim the route at the specified location, i.e
     * @param row The row of a {@link Track} in the {@link Route} to check.
     * @param col The column of a {@link Track} in the {@link Route} to check.
     * @return true or false
     */
    @Override
    public boolean canCurrentPlayerClaimRoute(int row, int col) {
        Player p = getCurrentPlayer();
        Route r = railroadMap.getRoute(row,col);
        if(railroadMap.getRoutes().contains(r)) {
            return p.canClaimRoute(r);
        }
        return false;
    }

    /**
     *Attempts to claim the route at the specified location on behalf of the current player
     * @param row The row of a {@link Track} in the {@link Route} to claim.
     * @param col The column of a {@link Track} in the {@link Route} to claim.
     * @throws RailroadBaronsException
     */
    @Override
    public void claimRoute(int row, int col) throws RailroadBaronsException {
        getCurrentPlayer().claimRoute(railroadMap.getRoute(row, col));
        railroadMap.routeClaimed(railroadMap.getRoute(row, col));

    }

    /**
     * adds route to claimed route for the ComputerPlayers
     * @param route
     * @throws RailroadBaronsException
     */
    public void ComputeClaim(Route route) throws RailroadBaronsException{
        railroadMap.routeClaimed(route);
    }

    /**
     * Called when the current player ends their turn
     */
    @Override
    public void endTurn() {
        for(RailroadBaronsObserver r: observers){
            r.turnEnded(this,getCurrentPlayer());
        }
        players.add(players.remove());
        if(!gameIsOver())
        {
            for(RailroadBaronsObserver r: observers){
                r.turnStarted(this,getCurrentPlayer());
            }
            if(deck.numberOfCardsRemaining() > 0) {
                getCurrentPlayer().startTurn(new CPair(deck.drawACard(), deck.drawACard()));
            }
            else{
                getCurrentPlayer().startTurn(new CPair(Card.NONE, Card.NONE));
            }
        }
    }

    /**
     * Returns the player whose turn it is
     * @return current player
     */
    @Override
    public Player getCurrentPlayer() {
        return players.peek();
    }

    /**
     * Returns all of the players currently playing the game
     * @return  collection of players
     */
    @Override
    public Collection<Player> getPlayers() {
            return players;
    }

    /**
     * Indicates whether or not the game is over
     * @return true or false game over
     */
    @Override
    public boolean gameIsOver() {
        if(railroadMap.getRoutes().isEmpty())
        {
            for(RailroadBaronsObserver r: observers){
                r.gameOver(this, whoWon());
            }
            return true;
        }
        for(Player player: players)
        {
            if(player.canContinuePlaying(railroadMap.getLengthOfShortestUnclaimedRoute()))
            {
                return false;
            }
        }
        for(RailroadBaronsObserver r: observers){
            r.gameOver(this, whoWon());
        }
        return true;
    }

    private Player whoWon(){
        Player highScorePlayer = null;
        for(Player p : players){
            if(highScorePlayer == null){
                highScorePlayer = p;
            }
            else {
                if(p.getScore() > highScorePlayer.getScore()){
                    highScorePlayer = p;
                }
            }
        }
        return highScorePlayer;

    }

    /**
     * Creates a graph of stations connected via routes
     * @return CStation Graph
     */
    public Graph<CStation> makeGraph()
    {
        Graph graph = new Graph();
        int largestAvailableColumn = 0;
        int smallestAvailableColumn = 25;
        int largestAvailableRow = 0;
        int smallestAvaiableRow = 25;

        for(Route route: railroadMap.getRoutes()){
            if(route.getOrigin().getCol() < smallestAvailableColumn){
                smallestAvailableColumn = route.getOrigin().getCol();
            }
            if(route.getOrigin().getCol() > largestAvailableColumn){
                largestAvailableColumn = route.getOrigin().getCol();
            }
            if(route.getDestination().getCol() < smallestAvailableColumn){
                smallestAvailableColumn = route.getDestination().getCol();
            }
            if(route.getDestination().getCol() > largestAvailableColumn){
                largestAvailableColumn = route.getDestination().getCol();
            }
            if(route.getOrigin().getRow() < smallestAvaiableRow){
                smallestAvaiableRow = route.getOrigin().getRow();
            }
            if(route.getOrigin().getRow() > largestAvailableRow){
                largestAvailableRow = route.getOrigin().getRow();
            }
            if(route.getDestination().getRow() < smallestAvaiableRow){
                smallestAvaiableRow = route.getDestination().getRow();
            }
            if(route.getDestination().getRow() > largestAvailableRow){
                largestAvailableRow = route.getDestination().getRow();
            }
        }

        this.north=new CStation("NORTH", new CSpace(smallestAvaiableRow,smallestAvailableColumn));
        Vertex northV = new Vertex(this.north);
        graph.addVertex(north);
        this.south=new CStation("South", new CSpace(largestAvailableRow,smallestAvailableColumn));
        Vertex southV = new Vertex(this.south);
        graph.addVertex(south);
        this.west=new CStation("west", new CSpace(smallestAvaiableRow,smallestAvailableColumn));
        Vertex westV = new Vertex(this.west);
        graph.addVertex(west);
        this.east=new CStation("east",new CSpace(smallestAvaiableRow,largestAvailableColumn));
        Vertex eastV = new Vertex(this.east);
        graph.addVertex(east);
        for(Route route: railroadMap.getRoutes())
        {
            if(!graph.contains(route.getOrigin()))
            {
                graph.addVertex(route.getOrigin());
            }
            if(!graph.contains(route.getDestination()))
            {
                graph.addVertex(route.getDestination());
            }
            graph.connect(route.getOrigin(),route.getDestination());
            if(route.getOrigin().getRow() == smallestAvaiableRow){
                graph.connect(route.getOrigin(),north);
            }
            else if(route.getOrigin().getRow() == largestAvailableRow){
                graph.connect(route.getOrigin(),south);
            }
            if(route.getOrigin().getCol() == smallestAvailableColumn){
                graph.connect(route.getOrigin(),west);
            }
            else if(route.getOrigin().getCol() == largestAvailableColumn){
                graph.connect(route.getOrigin(),east);
            }
            if(route.getDestination().getRow() == smallestAvaiableRow){
                graph.connect(route.getDestination(),north);
            }
            if(route.getDestination().getRow() == largestAvailableRow){
                graph.connect(route.getDestination(),south);
            }
            if(route.getDestination().getCol() == smallestAvailableColumn){
                graph.connect(route.getDestination(),west);
            }
            else if(route.getDestination().getCol() == largestAvailableColumn){
                graph.connect(route.getDestination(),east);
            }
        }

        return graph;
    }

    public Vertex getNorth(Vertex v)
    {
        return v;
    }
    public Vertex getSouth(Vertex v)
    {
        return v;
    }
    public Vertex getWest(Vertex v)
    {
        return v;
    }
    public Vertex getEast(Vertex v)
    {
        return v;
    }

    /**
     * searches graph for routes claimed by the given player that go through the graph from north to south
     * @param player player that might own routes
     * @return if player has routes through graph
     */
    public boolean searchNToS(Player player)
    {
        return graph.depthFirstSearch(north, south, player.getBaron(), railroadMap.getRoutes());
    }

    /**
     * searches graph for routes claimed by the given player that go through the graph from west to east
     * @param player player that might own routes
     * @return if player has routes through graph
     */
    public boolean searchWToE(Player player)
    {
        return graph.depthFirstSearch(west, east, player.getBaron(), railroadMap.getRoutes());
    }

    /**
     * gets the bonus points for north to south
     * @param player player getting points
     * @return bonus point
     */
    public int getBonusNToS(Player player)
    {
        if(searchNToS(player))
        {
            return 5*railroadMap.getRows();
        }
        return 0;
    }

    /**
     *  gets the bonus points for west to east
     * @param player player getting points
     * @return bonus point
     */
    public int getBonusWToE(Player player)
    {
        if(searchWToE(player))
        {
            return 5*railroadMap.getCols();
        }
        return 0;
    }

}
