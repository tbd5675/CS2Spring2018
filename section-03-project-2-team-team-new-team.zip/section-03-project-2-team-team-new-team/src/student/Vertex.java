package student;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Class representing a vertex in a graph
 * @param <T>
 */
    public class Vertex<T> {

        private T data;

        private List<Vertex<T>> neighbors;


        public Vertex(T data) {
            this.data = data;
            neighbors = new LinkedList<>();
        }

    /**
     * @return the list of neighbor vertices to this node.
     */
        public Collection<Vertex<T>> getNeighbors() {
            return neighbors;
        }

    /**
     * @return the information contained in the vertex
     */
        public T getData() {
            return data;
        }

    /**
     * adds a vertex to this vertex's neighbors
     * @param neighbor Vertex being added to this node's neighbors list
     */
        public void connectNeighbor(Vertex<T> neighbor) {
            neighbors.add(neighbor);
        }
    }

