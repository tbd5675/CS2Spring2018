package student;

import model.Card;
import model.Pair;

public class CPair implements Pair {
    private Card first;
    private Card second;

    /**
     * Constructor for a pair of cards
     * @param first card
     * @param second card
     */
    public CPair(Card first, Card second)
    {
        this.first=first;
        this.second=second;
    }

    /**
     * first card of pair
     * @return first card
     */
    @Override
    public Card getFirstCard() {
        return first;
    }

    /**
     * second card of pair
     * @return second card
     */
    @Override
    public Card getSecondCard() {
        return second;
    }
}
