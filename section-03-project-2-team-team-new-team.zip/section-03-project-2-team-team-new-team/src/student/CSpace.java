package student;

import model.Space;

/**
 * Class that represents the spaces on the Railroad Barons map.
 *
 */
public class CSpace implements Space {
    private int col;
    private int row;

    public CSpace(int row, int col){
        this.col = col;
        this.row = row;

    }

    /**
     * Returns the row of the space's location in the map.
     *
     * @return The row of the space's location in the map.
     */
    @Override
    public int getRow() {
        return this.row;
    }

    /**
     * Returns the column of the space's location in the map.
     *
     * @return The column of the space's location in the map.
     */
    @Override
    public int getCol() {
        return this.col;
    }

    /**
     * Returns true if the other space is occupying the same physical location
     * in the map as this space.
     *
     * @param otherSpace The other space to which this space is being compared for
     *              collocation.
     *
     * @return True if the two spaces are in the same physical location (row
     * and column) in the map; false otherwise.
     */
    @Override
    public boolean collocated(Space otherSpace) {

        return this.row == otherSpace.getRow() && this.col == otherSpace.getCol();
    }
}
