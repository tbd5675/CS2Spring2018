package student;

import model.Baron;
import model.RailroadBarons;
import model.Route;

import java.util.*;

public class Graph<T> {

        private final Map<T, Vertex<T>> vertices;

        public Graph() {
            vertices = new HashMap<>();
        }

        public void addVertex(T data) {
            Vertex<T> v = new Vertex<>(data);
            vertices.put(data, v);
        }

        public Vertex<T> getVertex(T data) {
            return vertices.get(data);
        }

        public void connect(T data1, T data2) {
            boolean addv1 = true;
            boolean addv2 = true;
            Vertex<T> v1 = getVertex(data1);
            Vertex<T> v2 = getVertex(data2);
            for(Vertex v: v1.getNeighbors()){
                if(v.equals(v2)){
                    addv2 = false;
                }
            }
            for(Vertex v: v2.getNeighbors()){
                if(v.equals(v1)){
                    addv1 = false;
                }
            }
            if(addv2) {
                v1.connectNeighbor(v2);
            }
            if(addv1) {
                v2.connectNeighbor(v1);
            }
        }

        public boolean depthFirstSearch(T data1, T data2, Baron baron, Collection<Route> routes) {
            Vertex<T> start = vertices.get(data1);
            Vertex<T> end = vertices.get(data2);
            return findPathDfs(start, end, baron, routes);
        }

        private boolean findPathDfs(Vertex<T> start, Vertex<T> end, Baron baron, Collection<Route> routes ) {
            Set<Vertex<T>> visited = new HashSet<>();
            visited.add(start);
            visitDfs(start, visited, baron, routes, start, end);

            return visited.contains(end);
        }

        private void visitDfs(Vertex<T> vertex, Set<Vertex<T>> visited, Baron baron, Collection<Route> routes, Vertex<T> start, Vertex<T> end) {
            for(Vertex<T> neighbor: vertex.getNeighbors()) {
                boolean found = false;
                for(Route r: routes) {
                    if((r.getOrigin() == vertex.getData() && r.getDestination() == neighbor.getData()) ||
                            (r.getOrigin() == neighbor.getData() && r.getDestination() == vertex.getData()) ) {
                        found = true;
                        if (!visited.contains(neighbor) && r.getBaron() == baron) {
                            visited.add(neighbor);
                            visitDfs(neighbor, visited, baron, routes, start,end);
                            break;
                        }
                    }
                }
                if(found == false && (vertex.equals(start) || neighbor.equals(end))){
                    if(!visited.contains(neighbor)){
                        visited.add(neighbor);
                        visitDfs(neighbor,visited,baron,routes,start,end);
                    }
                }
            }
        }

        public boolean contains(T data){
            for(T key: vertices.keySet()){
                if(key.equals(data)){
                    return true;
                }
            }
            return false;
        }
}
