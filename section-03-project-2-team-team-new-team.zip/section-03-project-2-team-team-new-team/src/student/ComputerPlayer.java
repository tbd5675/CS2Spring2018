package student;

import model.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class ComputerPlayer implements Player {
    private Baron baron;
    private LinkedList<Card> cardsInHand;
    private List<Route> routesClaimed;
    private int trainPieces;
    private int playerScore;
    private List<PlayerObserver> observers;
    public Deck deck;
    private RailroadBaronsLonelyEdition railroadBarons;

    public ComputerPlayer(Baron baron, Deck deck, RailroadBaronsLonelyEdition railroadBarons) {

        this.baron=baron;
        this.deck=deck;
        this.railroadBarons=railroadBarons;
        cardsInHand = new LinkedList<>();
        for (int x = 0; x < 4; x++) {
            cardsInHand.add(deck.drawACard());
        }
        routesClaimed = new LinkedList<>();
        trainPieces = 45;
        playerScore = 0;
        observers = new LinkedList<>();
    }
    /**
     * This is called at the start of every game to reset the player to its initial state:
     * Number of train pieces reset to the starting number of 45. All remaining cards cleared from hand.
     * Score reset to 0. Claimed routes cleared. Sets the most recently dealt Pair of cards to two Card.NONE values
     * @param dealt The hand of {@link Card cards} dealt to the player at the
     */
    @Override
    public void reset(Card... dealt) {

        cardsInHand.clear();
        cardsInHand.addAll(Arrays.asList(dealt).subList(0, 4));
        routesClaimed=new LinkedList<>();
        trainPieces=45;
        playerScore=0;
        for(PlayerObserver o: observers){
            o.playerChanged(this);
        }
    }
    /**
     * Adds an observer that will be notified when the player changes in some way
     * @param observer The new {@link PlayerObserver}.
     */
    @Override
    public void addPlayerObserver(PlayerObserver observer) {
        observers.add(observer);
    }
    /**
     * Removes an observer so that it is no longer notified when the player changes in some way
     * @param observer The {@link PlayerObserver} to remove.
     */
    @Override
    public void removePlayerObserver(PlayerObserver observer) {
        observers.remove(observer);
    }
    /**
     * The baron as which this player is playing the game
     * @return baron
     */
    @Override
    public Baron getBaron() {
        return baron;
    }
    /**
     * Used to start the player's next turn.
     * @param dealt a {@linkplain Pair pair of cards} to the player. Note that
     */
    @Override
    public void startTurn(Pair dealt) {
        if (dealt.getFirstCard() != Card.NONE) {
            cardsInHand.addFirst(dealt.getFirstCard());
        }
        if (dealt.getSecondCard() != Card.NONE) {
            cardsInHand.addFirst(dealt.getSecondCard());
        }
        for (PlayerObserver o : observers) {
            o.playerChanged(this);
        }
        takeTurn();
    }
    /**
     * Returns the most recently dealt pair of cards
     * @return pair of cards
     */
    @Override
    public Pair getLastTwoCards() {
        CPair pair = new CPair(cardsInHand.get(0),cardsInHand.get(1));
        return pair;
    }

    public void takeTurn()
    {
        for (Route route : railroadBarons.getRailroadMap().getRoutes()) {
            if (this.canClaimRoute(route)) {
                try {
                    claimRoute(route);
                } catch (RailroadBaronsException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
        railroadBarons.endTurn();
    }

    /**
     * Claims the given route on behalf of this player's Railroad Baron
     * @param route The {@link Route} to claim.
     *
     * @throws RailroadBaronsException
     */
    @Override
    public void claimRoute(Route route) throws RailroadBaronsException {
        while (canClaimRoute(route)) {
            int smallestAmountNeeded = route.getLength() - 1;
            int currentAmount = countCardsInHand(cardsInHand.get(0));
            Card smallest = null;
            for (Card c : cardsInHand) {
                if (c == Card.WILD) {
                    continue;
                }
                if (countCardsInHand(c) >= smallestAmountNeeded) {
                    if (currentAmount <= smallestAmountNeeded) {
                        currentAmount = countCardsInHand(c);
                        smallest = c;
                    } else if (countCardsInHand(c) < currentAmount) {
                        currentAmount = countCardsInHand(c);
                        smallest = c;
                    }
                }
            }
            if (currentAmount < smallestAmountNeeded) {
                int numWild = 1;
                for (Card c : cardsInHand) {
                    if (c == Card.WILD) {
                        continue;
                    }
                    if (countCardsInHand(c) + numWild >= smallestAmountNeeded) {
                        if (countCardsInHand(c) > countCardsInHand(smallest)) {
                            smallest = c;
                        }
                    }
                }
            }
            for (int i = 0; i < smallestAmountNeeded; i++) {
                if (countCardsInHand(smallest) > 0) {
                    cardsInHand.remove(smallest);
                } else {
                    cardsInHand.remove(Card.WILD);
                }
            }

            route.claim(baron);
            routesClaimed.add(route);
            railroadBarons.ComputeClaim(route);
            playerScore += route.getPointValue();
            trainPieces -= smallestAmountNeeded;
            for (PlayerObserver o : observers) {
                o.playerChanged(this);
            }
        }
    }
    /**
     * Returns the collection of routes claimed by this player
     * @return routes claimed
     */
    @Override
    public Collection<Route> getClaimedRoutes() {
            return routesClaimed;
    }
    /**
     * Returns the players current score based on the point value of each route that the player has currently claimed
     * @return accumulated score
     */
    @Override
    public int getScore() {
        if(playerScore == 0){
            return 0;
        }
        else {
            return playerScore + railroadBarons.getBonusNToS(this) + railroadBarons.getBonusWToE(this);
        }
    }
    /**
     * Returns true iff the following conditions are true: The player has enough cards (including wild cards)
     * to claim a route of the specified length. The player has enough train pieces to claim a route of the specified length.
     * @param shortestUnclaimedRoute The length of the shortest unclaimed
     *                               {@link Route} in the current game.
     *
     * @return
     */
    @Override
    public boolean canContinuePlaying(int shortestUnclaimedRoute) {
        if(trainPieces>=shortestUnclaimedRoute)
        {
            if(deck.numberOfCardsRemaining()==0)
            {
                for(Card c: cardsInHand)
                {
                    if(c == Card.WILD){
                        continue;
                    }
                    if(countCardsInHand(c)>=shortestUnclaimedRoute)
                    {
                        return true;
                    }
                    if(countCardsInHand(Card.WILD)>=1)
                    {
                        if(countCardsInHand(c)+1>=shortestUnclaimedRoute)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * Claims the given route on behalf of this player's Railroad Baron
     * @param route The {@link Route} to claim.
     *
     * @throws RailroadBaronsException
     */
    @Override
    public boolean canClaimRoute(Route route)
    {
        if(route.getBaron()!=Baron.UNCLAIMED){
            return false;
        }
        if( trainPieces>=route.getLength()-1)
        {
            for(Card c: cardsInHand)
            {
                if(c == Card.WILD){
                    continue;
                }
                if((this.countCardsInHand(c)) >= route.getLength()-1){
                    return true;
                }
                else if(this.countCardsInHand(Card.WILD) > 0) {
                    if ((this.countCardsInHand(c) + 1) >= route.getLength() - 1){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    /**
     * Returns the number of the specific kind of card that the player currently has in hand
     * @param card The {@link Card} of interest.
     * @return num of specific card
     */
    @Override
    public int countCardsInHand(Card card)
    {
        int num=0;
        for(Card c: cardsInHand)
        {
            if(c.equals(card))
            {
                num++;
            }
        }
        return num;
    }
    /**
     * Returns the number of game pieces that the player has remaining
     * @return game pieces
     */
    @Override
    public int getNumberOfPieces() {
        return this.trainPieces;
    }

    @Override
    public String toString() {
        return String.valueOf(this.baron);
    }
}
