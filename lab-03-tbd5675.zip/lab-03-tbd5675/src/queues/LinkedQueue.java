/**
 * Tate Dyer
 * Lab 3
 */

package queues;

import java.util.LinkedList;

public class LinkedQueue<T> implements IQueue<T>{

    LinkedList<T> myList= new LinkedList<>();

    /**
     * returns the size of the list
     * @return size
     */
    public int size()
    {
        return myList.size();
    }

    /**
     * checks if the list is empty
     * @return true or false
     */
    public boolean isEmpty()
    {
        return(myList.size()==0);
    }

    /**
     * returns the first goat in the list
     * @return first goat
     */
    public T front()
    {
        return myList.get(0);
    }

    /**
     * adds the given goat to the back of the list
     * @param goat
     */
    public void enqueue(T goat)
    {
        myList.add(goat);
    }

    /**
     * removes the first goat in the list
     * @return goat removed
     */
    public T dequeue()
    {
        return myList.remove();
    }
}
