/**
 * Tate Dyer
 * Lab 3
 */

package queues;

import goats.CuteGoat;
import goats.IGoat;

import java.util.Arrays;

public class ArrayQueue<T> implements IQueue<T> {

    private T[] goats;
    private int frontIndex=0;
    private int length=0;

    /**
     * constructor for array queue which takes in a size
     * @param size
     */
    public ArrayQueue(int size)
    {
        goats=(T[]) new Object[size];
    }

    /**
     * how many goats are in the queue
     * @return num goats
     */
    public int size()
    {
        return goats.length;
    }

    /**
     * check if the queue is empty
     * @return true or false
     */
    public boolean isEmpty()
    {
        return (length==0);
    }

    /**
     * gets the first item in the queue
     * @return first item
     */
    public T front()
    {
        return goats[frontIndex];
    }

    /**
     * given a goat adds it the queue
     * @param goat
     */
    public void enqueue(T goat)
    {
        int index=frontIndex;
        while(goats[index]!=null)
        {
           index=(index+1)%size();
        }
        goats[index]=goat;
        length=length+1;
    }

    /**
     * removes the first goat in the queue
     * @return the goat removed
     */
    public T dequeue()
    {
        goats[frontIndex]=null;
        frontIndex=(frontIndex+1)%size();
        length=length-1;
        return goats[frontIndex];


    }
}
