/**
 * Tate Dyer
 * Lab 3
 */

package trolls;

import goats.IGoat;

public class BattleTroll implements ITroll{
    private int HP;

    /**
     * constructor for the troll given the HP can take
     * @param HP
     */
    public BattleTroll(int HP)
    {
        this.HP=HP;
    }

    /**
     * interaction with the goat including calling the damage taken
     * @param goat
     */
    public void interact(IGoat goat)
    {
        adjustPower(goat.impact());
    }

    /**
     * changes the HP by the amount of damage
     * @param power
     */
    public void adjustPower(int power)
    {
        HP=HP-power;
    }

    /**
     * finishes interaction with either the troll getting killed or the troll eating the goat
     * @param goat
     */
    public void finished(IGoat goat)
    {
        if(isActive())
        {
            goat.setActive(false);
            System.out.println("The troll eats "+ goat+".");
        }
        else
        {
            System.out.println("The troll is vanquished by "+ goat+ "!");
        }
    }

    /**
     * checks if the troll is alive
     * @return true or false
     */
    public boolean isActive()
    {
        if(HP>0)
        {
            return true;
        }
        return false;
    }
}
