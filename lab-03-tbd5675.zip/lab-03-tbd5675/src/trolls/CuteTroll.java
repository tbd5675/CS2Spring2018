/**
 * Tate Dyer
 * Lab 3
 */

package trolls;

import goats.IGoat;

public class CuteTroll implements ITroll{

    private int maxHappy;

    /**
     * constructor for troll given its max happiness
     * @param maxHappy
     */
    public CuteTroll(int maxHappy)
    {
        this.maxHappy=maxHappy;
    }

    /**
     * the interaction between the troll and goat including petting and changing troll's happiness
     * @param goat
     */
    public void interact(IGoat goat)
    {
        System.out.println("The troll pets "+ goat.toString()+".");
        adjustPower(goat.impact());
    }

    /**
     * affects the happiness of the troll
     * @param power
     */
    public void adjustPower(int power)
    {
        maxHappy=maxHappy-power;
    }

    /**
     * finishes interaction either sending goat back to end of queue or by the troll falling asleep
     * @param goat
     */
    public void finished(IGoat goat)
    {
        if(isActive())
        {
            //send goat to back
            System.out.println(goat + " returns to the back of the line.");
        }
        else
        {
            System.out.println("The troll falls asleep after petting "+ goat+".");
        }
    }

    /**
     * checks if the troll is awake
     * @return true or false
     */
    public boolean isActive()
    {
        if(maxHappy>0)
        {
            return true;
        }
        return false;
    }


}
