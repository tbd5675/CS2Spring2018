/**
 * Tate Dyer
 * Lab 3
 */

package trolls;

import goats.IGoat;

public interface ITroll{
    /**
     * Method to change the HP or happiness of the troll
     *
     * @return new power
     */
    void interact(IGoat goat);

    /**
     * Troll interaction with the goat as it approaches the troll bridge.
     *
     * @return String containing the trolls action such as petting or eating the goat
     */
    void adjustPower(int power);

    /**
     * What is said if the troll is finished
     *
     * @return String containing the troll being vanquished or put to sleep
     */
    void finished(IGoat goat);

    /**
     * Method used to determine if the troll is still active.
     *
     * @return True if the troll is still active, false otherwise.
     */
    boolean isActive();
}
