package lab01.student;

import java.util.Scanner;

import static turtle.Turtle.*;

/**
 * Tate Dyer
 * CS2 Lab1
 */
public class HTree
{
    /**
     * Initialize the graphics
     * @param length of the main snowflake branch
     * @param depth depth of recursion
     */
    public static void init(int length, int depth)
    {
        Turtle.setWorldCoordinates(-length*2,-length*2,length*2,length*2);
        Turtle.title("H-Tree, depth: "+ depth);
    }

    /**
     * Recursively draw the H-Tree
     * @param length length of current h-tree segments
     * @param depth current depth of recursion
     */
    public static void drawHTree(int length, int depth)
    {
        if (depth>0)
        {
            //start in center of H, move upper right
            Turtle.fd(length/2);
            Turtle.left(90);
            Turtle.fd(length/2);
            Turtle.right(90);
            //recurse
            drawHTree(length/2, depth-1);
            //move to lower right of H
            Turtle.right(90);
            Turtle.fd(length);
            Turtle.left(90);
            //recurse
            drawHTree(length/2, depth-1);
            //move to upper left of H
            Turtle.left(90);
            Turtle.fd(length/2);
            Turtle.left(90);
            Turtle.fd(length);
            Turtle.right(90);
            Turtle.fd(length/2);
            Turtle.right(90);
            //recurse
            drawHTree(length/2, depth-1);
            //move to lower left of H
            Turtle.right(90);
            Turtle.fd(length);
            Turtle.left(90);
            //recurse
            drawHTree(length/2, depth-1);
            //return to center of H
            Turtle.left(90);
            Turtle.fd(length/2);
            Turtle.right(90);
            Turtle.fd(length/2);

        }
    }

    /**
     * Main method reads the command line for argument for the depth and draws the h-tree
     * @param args
     */
    public static void main(String[] args)
    {
        if(args.length == 1)
        {
            int MAX_SEGMENT_LENGTH = 200;
            init(MAX_SEGMENT_LENGTH, Integer.parseInt(args[0]));
            drawHTree(MAX_SEGMENT_LENGTH, 3);
            System.out.println("Close the window to exit the program.");
        }
        else
        {
            System.out.println("Error in command line argument.");
        }
    }

}



