package lab01.student;

import java.util.Scanner;
/**
 * Tate Dyer
 * CS2 Lab1
 */
public class GoodHashFunc
{
    /**
     * iterates over characters in string, storing the hash of each in a an index in an array
     * @param word input word
     * @return
     */
    public static int computeHash(String word)
    {
        int[] vals=new int[word.length()];
        for(int i=0; i<word.length(); i++)
        {
            vals[i]=(int)(word.charAt(i)*Math.pow(31, word.length()-(i+1)));
        }
        int sum=0;
        int count=0;
        while(count<word.length())
        {
            sum+=vals[count];
            count++;
        }
        return sum;
    }

    /**
     *prompts for string, uses computeHash function to compute hash value to print
     * @param args
     */
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string: ");
        String word=sc.next();
        int val=computeHash(word);
        System.out.println("The computed hash for the specified string is: "+ val);
    }
}
