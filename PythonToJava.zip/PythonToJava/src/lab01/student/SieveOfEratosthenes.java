package lab01.student;

import java.util.Scanner;
/**
 * Tate Dyer
 * CS2 Lab1
 */
public class SieveOfEratosthenes
{
    /**
     * builds an array from 2 to the upperBound and changes all 0s to 1 if not Prime
     * @param upperBound input max number
     * @return
     */
    public static int[] makeSieve(int upperBound)
    {
        int[] vals=new int[upperBound+1];
        for(int i=0; i<vals.length; i++)
        {
            if(i==0||i==1)
            {
                vals[i]=1;
            }
            else if(i==2)
            {
                vals[i]=0;
            }
            else
                {
                    int root= (int)Math.floor(Math.sqrt(i));
                    for(int j=2; j<=root; j++)
                    {
                        if(i%j==0)
                        {
                            vals[i]=1;
                        }
                    }
                }
        }
        return vals;
    }

    /**
     * Prompts user for upperBound, uses makeSieve to build an array, then continually prompts user to enter numbers
     * in the range to use array to figure out if prime or not
     * @param args
     */
    public static void main(String[] args)
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter an upper bound:");
        int upper=sc.nextInt();
        int[] vals=makeSieve(upper); //cause starts at 2
        int num=sc.nextInt();
        while(num>=1)
        {
            if (num==1)
            {
                System.out.println(num +" is not prime");
            }
            else
            {
                if(vals[num]==0)
                {
                    System.out.println(num + " is prime");
                }
                else
                {
                    System.out.println(num +" is not prime");
                }
            }
            System.out.println("Enter an integer (0 to quit):");
            num=sc.nextInt();
        }
        System.out.println("Goodbye!");
        System.exit(0);
    }
}
