package lab01.student;

import java.util.Scanner;
/**
 * Tate Dyer
 * CS2 Lab1
 */
public class PrimalityTest
{
    /**
     * Given a number determines if prime or not
     * @param num input int
     * @return true if prime and false if not
     */
    public static boolean isPrime(int num)
    {
        int root= (int)Math.floor(Math.sqrt(num));
        if (num==1)
        {
            return false;
        }
        else if (num==2)
        {
            return true;
        }
        else if(num%2==0)
        {
            return false;
        }
        else
        {
            for(int i=3; i<=root; i=i+2)
            {
                if (num%i==0)
                {
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * Prompts user for number, terminates if less than 1 printing goodbye, else uses isPrime to print if Prime or not
     * @param args
     */
    public static void main(String[]args)
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter an integer (0 to quit):");
        int num=sc.nextInt();
        boolean val=isPrime(num);
        while(num>1)
        {
            if (val==true)
            {
                System.out.println(num +" is prime");
            }
            else
            {
                System.out.println(num +" is not prime");
            }
            System.out.println("Enter an integer (0 to quit):");
            num=sc.nextInt();
        }
        System.out.println("Goodbye!");
        System.exit(0);
    }
}
