package server;

import static common.ChatterboxProtocol.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Map;
import java.util.Scanner;

public class Client implements Runnable{
    private Map<String, Client> clients;
    private PrintWriter out;
    private Scanner in;
    private Socket socket;
    private String name="unknown user";
    public boolean connected= false;

    /**
     * constructor for the class that takes in what the client inputs and allows the server to do or send actions back
     * @param socket
     * @param clients
     */
    public Client(Socket socket, Map clients)
    {
        this.socket=socket;
        this.clients=clients;
        try{
            out=new PrintWriter(this.socket.getOutputStream(), true);
            in=new Scanner(this.socket.getInputStream());
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * runs the client that interacts with the server
     */
    @Override
    public void run()
    {
        while(true)
        {
            if (in.hasNextLine())
            {
                String input = in.nextLine();
                System.out.println("<<" + this.name + ": " + input);
                String[] message = input.split(SEPARATOR);
                if (message[0].equals(CONNECT))
                {
                    connect(message);
                }
                else if(message[0].equals(DISCONNECT) && connected && message.length==1)
                {
                    disconnect();
                    break;
                }
                else if(message[0].equals(LIST_USERS) && connected && message.length==1)
                {
                    list_users();
                }
                else if(message[0].equals(SEND_CHAT) && connected && message.length==2)
                {
                    send_chat(message);
                }
                else if(message[0].equals(SEND_WHISPER) && connected && message.length==3)
                {
                    send_whisper(message);
                }

                else if(connected)
                {
                    error("Unknown or unexpected protocol message: "+input);
                }
                else
                {
                    fatal_error("Intial connect message not recieved");
                }
            }
        }
    }

    /**
     * prints out output
     * @param output
     */
    public void output(String output)
    {
        out.println(output);
    }

    /**
     * if there is an error is called to output message
     * @param error that is given
     */
    public void error(String error)
    {
        out.println(FATAL_ERROR+SEPARATOR+error);
        System.out.println(ERROR+SEPARATOR+error);
    }

    /**
     * if there is an error that is fatal is called to output message
     * @param error that is given
     */
    public void fatal_error(String error)
    {
        out.println(ERROR+SEPARATOR+error);
        System.out.println(ERROR+SEPARATOR+error);
    }

    /**
     * server side of the connect action
     * @param message string array of messages
     */
    public void connect(String[] message)
    {
        this.name = message[1];
        out.println("Welcome to Chatterbox! Type 'help' to see a list of the commands");
        for (Client client : clients.values()) {
            System.out.println(">>" + client.name + ": " + USER_JOINED + SEPARATOR + this.name);
            client.output("A user has joined the Chatterbox server: " + this.name);
        }
        clients.put(name, this);
        connected = true;
        System.out.println(">>" + name + " " + CONNECTED);
        System.out.println("Waiting for connections on port "+Server.getPort());
    }

    /**
     * server side of the disconnect action
     */
    public void disconnect()
    {
        out.println("Goodbye!");
        System.out.println(">>"+this.name+": "+DISCONNECTED);
        clients.remove(this.name);
        for(Client client:clients.values())
        {
            System.out.println(">>"+client.name+": "+USER_LEFT+SEPARATOR+this.name);
            client.output("A user has left the server: " +this.name);
        }
        in.close();
        out.close();
    }

    /**
     * server side of sending a chat and the client receiving
     * @param message string array of messages
     */
    public void send_chat(String[] message)
    {
        for(Client client:clients.values())
        {
            System.out.println(">>"+client.name+": " + CHAT_RECEIVED+SEPARATOR+this.name+SEPARATOR+message[1]);
            client.output(name+" said: " +message[1]);
        }
    }

    /**
     * server side of sending a message to a specific other client
     * @param message string array of messages
     */
    public void send_whisper(String[] message)
    {
        if(clients.keySet().contains(message[1]))
        {
            clients.get(message[1]).output(this.name+" whispers to you: "+message[2]);
            out.println("You whispered to "+message[1]+": "+message[2]);
            System.out.println(">>"+clients.get(message[1]).name+": "+WHISPER_RECEIVED+SEPARATOR+this.name+SEPARATOR+message[2]);
        }
        else
        {
            out.println("No user " +message[1]+" found.");
        }
    }

    /**
     * server side of outputting the current users on the server
     */
    public void list_users()
    {
        StringBuilder users = new StringBuilder();
        users.append(">>"+this.name+": "+USERS);
        out.println("The following users are connected:");
        for(String name:clients.keySet())
        {
            users.append(SEPARATOR+name);
            out.println(name);
        }
        System.out.println(users);
    }
}
