package server;

import java.io.IOException;
import java.net.ServerSocket;

public class Main {

    private static final int PORT=7896;

    public static void main(String[] args) throws IOException{
        ServerSocket serverSocket=new ServerSocket(PORT);
        Server server=new Server(serverSocket);
        Thread t=new Thread(server);
        t.start();
    }
}
