package server;

import common.ChatterboxProtocol;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Server implements Runnable{

    private static final int PORT=7896;
    private ServerSocket server;
    private Map<String, Client> clients = new HashMap<>();

    /**
     * constructor for the server
     * @param server
     */
    public Server(ServerSocket server)
    {
        this.server=server;
    }

    /**
     * runs the server that can be interacted with
     */
    @Override
    public void run()
    {
        System.out.println("Waiting for connections on port "+ PORT);
        while(true)
        {
            try {
                Socket socket=server.accept();
                Client client= new Client(socket, clients);
                Thread t=new Thread(client);
                t.start();
                System.out.println("ChatterboxClient connection received from "+ socket.getRemoteSocketAddress().toString());
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static int getPort()
    {
        return PORT;
    }

}
