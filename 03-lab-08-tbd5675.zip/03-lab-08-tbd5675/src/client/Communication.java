package client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Communication implements Runnable{

    private Scanner in;
    private Socket socket;
    private PrintWriter out;

    /**
     * constructor for what allows the communication to go between the server and clients smoother
     * @param socket that connects the client and server
     * @throws IOException
     */
    public Communication(Socket socket) throws IOException
    {
        this.socket=socket;
        this.in=new Scanner(this.socket.getInputStream());
    }

    /**
     * run method for the output from the communication
     */
    @Override
    public void run()
    {
        while(true)
        {
            if(in.hasNextLine())
            {
                String output=in.nextLine();
                System.out.println(output);
            }
        }
    }
}
