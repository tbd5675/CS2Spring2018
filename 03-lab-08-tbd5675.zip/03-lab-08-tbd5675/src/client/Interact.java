package client;

import common.ChatterboxProtocol;

import static common.ChatterboxProtocol.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Interact implements Runnable{
    private Scanner in;
    private Socket socket;
    private PrintWriter out;
    private String name;
    private boolean connected=false;

    /**
     * constructor for the client
     * @param socket of the client that connects to the server
     * @param name of the client
     * @throws IOException
     */
    public Interact(Socket socket, String name) throws IOException
    {
        this.socket=socket;
        this.in=new Scanner(System.in);
        this.out=new PrintWriter(this.socket.getOutputStream(), true);
        this.name=name;
    }

    /**
     * the run method for what is really the client taking in the user input to determine how to interact with the server
     */
    @Override
    public void run()
    {
        out.println(CONNECT+SEPARATOR+this.name);
        connected=true;
        while(true && connected)
        {
            if(in.hasNextLine())
            {
                String[] input=in.nextLine().split(" ");
                String command=input[0];
                if(command.equals("/help"))
                {
                    help();
                }
                else if(command.equals("/quit"))
                {
                    quit();
                    break;
                }
                else if(command.equals("/c") && input.length==2)
                {
                    out.println(SEND_CHAT+SEPARATOR+input[1]);
                }
                else if(command.equals("/w")&& input.length==3)
                {
                    out.println(SEND_WHISPER+SEPARATOR+input[1]+SEPARATOR+input[2]);
                }
                else if(command.equals("/list"))
                {
                    out.println(LIST_USERS);
                }
                else
                {
                    System.out.println("No such command/invalid syntax");
                }
            }
        }
    }

    /**
     * prints out the message if the user input help
     */
    public void help()
    {
        System.out.println("/help- displays this message"+
                "\n/quit- quits Chatterbox"+
                "\n//c<message>- sends a message to all currently connected users"+
                "\n//w<recipient> <message> - sends a private message to the recipient"+
                "\n/list- display a list of currently connected users");
    }

    /**
     * asks if the user wants to quit- if they do it quits and if not keeps going for next input
     */
    public void quit()
    {
        System.out.println("Are you sure(y/n): ");
        if(in.hasNextLine())
        {
            String confirm=in.nextLine();
            if(confirm.equals("y"))
            {
                out.println(ChatterboxProtocol.DISCONNECT);
                connected=false;
            }
            if(confirm.equals("n"))
            {
                System.out.println("Not disconnected");
            }
        }
    }
}
