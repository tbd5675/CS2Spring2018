package client;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

import static java.lang.Integer.parseInt;

public class Main {
    public static void main(String[] args) throws IOException{
        Scanner sc=new Scanner(System.in);
        System.out.print("Chatterbox server host: ");
        String host=sc.nextLine();
        System.out.print("Chatterbox server port: ");
        int PORT=parseInt(sc.nextLine());
        System.out.print("Username: ");
        String username=sc.nextLine();

        Socket socket=new Socket(host, PORT);
        Interact interact=new Interact(socket, username);
        Thread t=new Thread(interact);
        t.start();
        Communication communication=new Communication(socket);
        Thread u=new Thread(communication);
        u.start();
    }
}
